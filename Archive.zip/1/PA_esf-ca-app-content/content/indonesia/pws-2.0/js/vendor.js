!(function (e, t) {
	"use strict";
	"object" == typeof module && "object" == typeof module.exports
		? (module.exports = e.document
				? t(e, !0)
				: function (e) {
						if (!e.document) throw new Error("jQuery requires a window with a document");
						return t(e);
				  })
		: t(e);
})("undefined" != typeof window ? window : this, function (e, t) {
	"use strict";
	function n(e, t, n) {
		var r,
			i,
			o = (n = n || fe).createElement("script");
		if (((o.text = e), t)) for (r in pe) (i = t[r] || (t.getAttribute && t.getAttribute(r))) && o.setAttribute(r, i);
		n.head.appendChild(o).parentNode.removeChild(o);
	}
	function r(e) {
		return null == e ? e + "" : "object" == typeof e || "function" == typeof e ? re[ie.call(e)] || "object" : typeof e;
	}
	function i(e) {
		var t = !!e && "length" in e && e.length,
			n = r(e);
		return !le(e) && !ce(e) && ("array" === n || 0 === t || ("number" == typeof t && 0 < t && t - 1 in e));
	}
	function o(e, t) {
		return e.nodeName && e.nodeName.toLowerCase() === t.toLowerCase();
	}
	function s(e, t, n) {
		return le(t)
			? he.grep(e, function (e, r) {
					return !!t.call(e, r, e) !== n;
			  })
			: t.nodeType
			? he.grep(e, function (e) {
					return (e === t) !== n;
			  })
			: "string" != typeof t
			? he.grep(e, function (e) {
					return -1 < ne.call(t, e) !== n;
			  })
			: he.filter(t, e, n);
	}
	function a(e, t) {
		for (; (e = e[t]) && 1 !== e.nodeType; );
		return e;
	}
	function u(e) {
		return e;
	}
	function l(e) {
		throw e;
	}
	function c(e, t, n, r) {
		var i;
		try {
			e && le((i = e.promise)) ? i.call(e).done(t).fail(n) : e && le((i = e.then)) ? i.call(e, t, n) : t.apply(void 0, [e].slice(r));
		} catch (e) {
			n.apply(void 0, [e]);
		}
	}
	function f() {
		fe.removeEventListener("DOMContentLoaded", f), e.removeEventListener("load", f), he.ready();
	}
	function p(e, t) {
		return t.toUpperCase();
	}
	function d(e) {
		return e.replace(De, "ms-").replace(Ne, p);
	}
	function h() {
		this.expando = he.expando + h.uid++;
	}
	function g(e, t, n) {
		var r, i;
		if (void 0 === n && 1 === e.nodeType)
			if (((r = "data-" + t.replace(Oe, "-$&").toLowerCase()), "string" == typeof (n = e.getAttribute(r)))) {
				try {
					n = "true" === (i = n) || ("false" !== i && ("null" === i ? null : i === +i + "" ? +i : _e.test(i) ? JSON.parse(i) : i));
				} catch (e) {}
				qe.set(e, t, n);
			} else n = void 0;
		return n;
	}
	function v(e, t, n, r) {
		var i,
			o,
			s = 20,
			a = r
				? function () {
						return r.cur();
				  }
				: function () {
						return he.css(e, t, "");
				  },
			u = a(),
			l = (n && n[3]) || (he.cssNumber[t] ? "" : "px"),
			c = e.nodeType && (he.cssNumber[t] || ("px" !== l && +u)) && Ie.exec(he.css(e, t));
		if (c && c[3] !== l) {
			for (u /= 2, l = l || c[3], c = +u || 1; s--; ) he.style(e, t, c + l), (1 - o) * (1 - (o = a() / u || 0.5)) <= 0 && (s = 0), (c /= o);
			(c *= 2), he.style(e, t, c + l), (n = n || []);
		}
		return n && ((c = +c || +u || 0), (i = n[1] ? c + (n[1] + 1) * n[2] : +n[2]), r && ((r.unit = l), (r.start = c), (r.end = i))), i;
	}
	function m(e, t) {
		for (var n, r, i, o, s, a, u, l = [], c = 0, f = e.length; c < f; c++)
			(r = e[c]).style &&
				((n = r.style.display),
				t
					? ("none" === n && ((l[c] = Le.get(r, "display") || null), l[c] || (r.style.display = "")),
					  "" === r.style.display &&
							We(r) &&
							(l[c] =
								((u = s = o = void 0),
								(s = (i = r).ownerDocument),
								(a = i.nodeName),
								(u = Be[a]) || ((o = s.body.appendChild(s.createElement(a))), (u = he.css(o, "display")), o.parentNode.removeChild(o), "none" === u && (u = "block"), (Be[a] = u)))))
					: "none" !== n && ((l[c] = "none"), Le.set(r, "display", n)));
		for (c = 0; c < f; c++) null != l[c] && (e[c].style.display = l[c]);
		return e;
	}
	function y(e, t) {
		var n;
		return (n = void 0 !== e.getElementsByTagName ? e.getElementsByTagName(t || "*") : void 0 !== e.querySelectorAll ? e.querySelectorAll(t || "*") : []), void 0 === t || (t && o(e, t)) ? he.merge([e], n) : n;
	}
	function b(e, t) {
		for (var n = 0, r = e.length; n < r; n++) Le.set(e[n], "globalEval", !t || Le.get(t[n], "globalEval"));
	}
	function x(e, t, n, i, o) {
		for (var s, a, u, l, c, f, p = t.createDocumentFragment(), d = [], h = 0, g = e.length; h < g; h++)
			if ((s = e[h]) || 0 === s)
				if ("object" === r(s)) he.merge(d, s.nodeType ? [s] : s);
				else if (Ye.test(s)) {
					for (a = a || p.appendChild(t.createElement("div")), u = (Ve.exec(s) || ["", ""])[1].toLowerCase(), l = Ge[u] || Ge._default, a.innerHTML = l[1] + he.htmlPrefilter(s) + l[2], f = l[0]; f--; ) a = a.lastChild;
					he.merge(d, a.childNodes), ((a = p.firstChild).textContent = "");
				} else d.push(t.createTextNode(s));
		for (p.textContent = "", h = 0; (s = d[h++]); )
			if (i && -1 < he.inArray(s, i)) o && o.push(s);
			else if (((c = Pe(s)), (a = y(p.appendChild(s), "script")), c && b(a), n)) for (f = 0; (s = a[f++]); ) Xe.test(s.type || "") && n.push(s);
		return p;
	}
	function w() {
		return !0;
	}
	function T() {
		return !1;
	}
	function C(e, t) {
		return (
			(e ===
				(function () {
					try {
						return fe.activeElement;
					} catch (e) {}
				})()) ==
			("focus" === t)
		);
	}
	function E(e, t, n, r, i, o) {
		var s, a;
		if ("object" == typeof t) {
			for (a in ("string" != typeof n && ((r = r || n), (n = void 0)), t)) E(e, a, n, r, t[a], o);
			return e;
		}
		if ((null == r && null == i ? ((i = n), (r = n = void 0)) : null == i && ("string" == typeof n ? ((i = r), (r = void 0)) : ((i = r), (r = n), (n = void 0))), !1 === i)) i = T;
		else if (!i) return e;
		return (
			1 === o &&
				((s = i),
				((i = function (e) {
					return he().off(e), s.apply(this, arguments);
				}).guid = s.guid || (s.guid = he.guid++))),
			e.each(function () {
				he.event.add(this, t, i, r, n);
			})
		);
	}
	function S(e, t, n) {
		n
			? (Le.set(e, t, !1),
			  he.event.add(e, t, {
					namespace: !1,
					handler: function (e) {
						var r,
							i,
							o = Le.get(this, t);
						if (1 & e.isTrigger && this[t]) {
							if (o.length) (he.event.special[t] || {}).delegateType && e.stopPropagation();
							else if (((o = Z.call(arguments)), Le.set(this, t, o), (r = n(this, t)), this[t](), o !== (i = Le.get(this, t)) || r ? Le.set(this, t, !1) : (i = {}), o !== i)) return e.stopImmediatePropagation(), e.preventDefault(), i.value;
						} else o.length && (Le.set(this, t, { value: he.event.trigger(he.extend(o[0], he.Event.prototype), o.slice(1), this) }), e.stopImmediatePropagation());
					},
			  }))
			: void 0 === Le.get(e, t) && he.event.add(e, t, w);
	}
	function k(e, t) {
		return (o(e, "table") && o(11 !== t.nodeType ? t : t.firstChild, "tr") && he(e).children("tbody")[0]) || e;
	}
	function A(e) {
		return (e.type = (null !== e.getAttribute("type")) + "/" + e.type), e;
	}
	function D(e) {
		return "true/" === (e.type || "").slice(0, 5) ? (e.type = e.type.slice(5)) : e.removeAttribute("type"), e;
	}
	function N(e, t) {
		var n, r, i, o, s, a;
		if (1 === t.nodeType) {
			if (Le.hasData(e) && (a = Le.get(e).events)) for (i in (Le.remove(t, "handle events"), a)) for (n = 0, r = a[i].length; n < r; n++) he.event.add(t, i, a[i][n]);
			qe.hasData(e) && ((o = qe.access(e)), (s = he.extend({}, o)), qe.set(t, s));
		}
	}
	function j(e, t, r, i) {
		t = ee(t);
		var o,
			s,
			a,
			u,
			l,
			c,
			f = 0,
			p = e.length,
			d = p - 1,
			h = t[0],
			g = le(h);
		if (g || (1 < p && "string" == typeof h && !ue.checkClone && et.test(h)))
			return e.each(function (n) {
				var o = e.eq(n);
				g && (t[0] = h.call(this, n, o.html())), j(o, t, r, i);
			});
		if (p && ((s = (o = x(t, e[0].ownerDocument, !1, e, i)).firstChild), 1 === o.childNodes.length && (o = s), s || i)) {
			for (u = (a = he.map(y(o, "script"), A)).length; f < p; f++) (l = o), f !== d && ((l = he.clone(l, !0, !0)), u && he.merge(a, y(l, "script"))), r.call(e[f], l, f);
			if (u)
				for (c = a[a.length - 1].ownerDocument, he.map(a, D), f = 0; f < u; f++)
					(l = a[f]),
						Xe.test(l.type || "") &&
							!Le.access(l, "globalEval") &&
							he.contains(c, l) &&
							(l.src && "module" !== (l.type || "").toLowerCase() ? he._evalUrl && !l.noModule && he._evalUrl(l.src, { nonce: l.nonce || l.getAttribute("nonce") }, c) : n(l.textContent.replace(tt, ""), l, c));
		}
		return e;
	}
	function L(e, t, n) {
		for (var r, i = t ? he.filter(t, e) : e, o = 0; null != (r = i[o]); o++) n || 1 !== r.nodeType || he.cleanData(y(r)), r.parentNode && (n && Pe(r) && b(y(r, "script")), r.parentNode.removeChild(r));
		return e;
	}
	function q(e, t, n) {
		var r,
			i,
			o,
			s,
			a = e.style;
		return (
			(n = n || rt(e)) &&
				("" !== (s = n.getPropertyValue(t) || n[t]) || Pe(e) || (s = he.style(e, t)),
				!ue.pixelBoxStyles() && nt.test(s) && ot.test(t) && ((r = a.width), (i = a.minWidth), (o = a.maxWidth), (a.minWidth = a.maxWidth = a.width = s), (s = n.width), (a.width = r), (a.minWidth = i), (a.maxWidth = o))),
			void 0 !== s ? s + "" : s
		);
	}
	function _(e, t) {
		return {
			get: function () {
				if (!e()) return (this.get = t).apply(this, arguments);
				delete this.get;
			},
		};
	}
	function O(e) {
		var t = he.cssProps[e] || ut[e];
		return (
			t ||
			(e in at
				? e
				: (ut[e] =
						(function (e) {
							for (var t = e[0].toUpperCase() + e.slice(1), n = st.length; n--; ) if ((e = st[n] + t) in at) return e;
						})(e) || e))
		);
	}
	function R(e, t, n) {
		var r = Ie.exec(t);
		return r ? Math.max(0, r[2] - (n || 0)) + (r[3] || "px") : t;
	}
	function I(e, t, n, r, i, o) {
		var s = "width" === t ? 1 : 0,
			a = 0,
			u = 0;
		if (n === (r ? "border" : "content")) return 0;
		for (; s < 4; s += 2)
			"margin" === n && (u += he.css(e, n + He[s], !0, i)),
				r
					? ("content" === n && (u -= he.css(e, "padding" + He[s], !0, i)), "margin" !== n && (u -= he.css(e, "border" + He[s] + "Width", !0, i)))
					: ((u += he.css(e, "padding" + He[s], !0, i)), "padding" !== n ? (u += he.css(e, "border" + He[s] + "Width", !0, i)) : (a += he.css(e, "border" + He[s] + "Width", !0, i)));
		return !r && 0 <= o && (u += Math.max(0, Math.ceil(e["offset" + t[0].toUpperCase() + t.slice(1)] - o - u - a - 0.5)) || 0), u;
	}
	function H(e, t, n) {
		var r = rt(e),
			i = (!ue.boxSizingReliable() || n) && "border-box" === he.css(e, "boxSizing", !1, r),
			s = i,
			a = q(e, t, r),
			u = "offset" + t[0].toUpperCase() + t.slice(1);
		if (nt.test(a)) {
			if (!n) return a;
			a = "auto";
		}
		return (
			((!ue.boxSizingReliable() && i) || (!ue.reliableTrDimensions() && o(e, "tr")) || "auto" === a || (!parseFloat(a) && "inline" === he.css(e, "display", !1, r))) &&
				e.getClientRects().length &&
				((i = "border-box" === he.css(e, "boxSizing", !1, r)), (s = u in e) && (a = e[u])),
			(a = parseFloat(a) || 0) + I(e, t, n || (i ? "border" : "content"), s, r, a) + "px"
		);
	}
	function M(e, t, n, r, i) {
		return new M.prototype.init(e, t, n, r, i);
	}
	function P() {
		ht && (!1 === fe.hidden && e.requestAnimationFrame ? e.requestAnimationFrame(P) : e.setTimeout(P, he.fx.interval), he.fx.tick());
	}
	function F() {
		return (
			e.setTimeout(function () {
				dt = void 0;
			}),
			(dt = Date.now())
		);
	}
	function W(e, t) {
		var n,
			r = 0,
			i = { height: e };
		for (t = t ? 1 : 0; r < 4; r += 2 - t) i["margin" + (n = He[r])] = i["padding" + n] = e;
		return t && (i.opacity = i.width = e), i;
	}
	function B(e, t, n) {
		for (var r, i = ($.tweeners[t] || []).concat($.tweeners["*"]), o = 0, s = i.length; o < s; o++) if ((r = i[o].call(n, t, e))) return r;
	}
	function $(e, t, n) {
		var r,
			i,
			o = 0,
			s = $.prefilters.length,
			a = he.Deferred().always(function () {
				delete u.elem;
			}),
			u = function () {
				if (i) return !1;
				for (var t = dt || F(), n = Math.max(0, l.startTime + l.duration - t), r = 1 - (n / l.duration || 0), o = 0, s = l.tweens.length; o < s; o++) l.tweens[o].run(r);
				return a.notifyWith(e, [l, r, n]), r < 1 && s ? n : (s || a.notifyWith(e, [l, 1, 0]), a.resolveWith(e, [l]), !1);
			},
			l = a.promise({
				elem: e,
				props: he.extend({}, t),
				opts: he.extend(!0, { specialEasing: {}, easing: he.easing._default }, n),
				originalProperties: t,
				originalOptions: n,
				startTime: dt || F(),
				duration: n.duration,
				tweens: [],
				createTween: function (t, n) {
					var r = he.Tween(e, l.opts, t, n, l.opts.specialEasing[t] || l.opts.easing);
					return l.tweens.push(r), r;
				},
				stop: function (t) {
					var n = 0,
						r = t ? l.tweens.length : 0;
					if (i) return this;
					for (i = !0; n < r; n++) l.tweens[n].run(1);
					return t ? (a.notifyWith(e, [l, 1, 0]), a.resolveWith(e, [l, t])) : a.rejectWith(e, [l, t]), this;
				},
			}),
			c = l.props;
		for (
			(function (e, t) {
				var n, r, i, o, s;
				for (n in e)
					if (((i = t[(r = d(n))]), (o = e[n]), Array.isArray(o) && ((i = o[1]), (o = e[n] = o[0])), n !== r && ((e[r] = o), delete e[n]), (s = he.cssHooks[r]) && ("expand" in s)))
						for (n in ((o = s.expand(o)), delete e[r], o)) (n in e) || ((e[n] = o[n]), (t[n] = i));
					else t[r] = i;
			})(c, l.opts.specialEasing);
			o < s;
			o++
		)
			if ((r = $.prefilters[o].call(l, e, c, l.opts))) return le(r.stop) && (he._queueHooks(l.elem, l.opts.queue).stop = r.stop.bind(r)), r;
		return he.map(c, B, l), le(l.opts.start) && l.opts.start.call(e, l), l.progress(l.opts.progress).done(l.opts.done, l.opts.complete).fail(l.opts.fail).always(l.opts.always), he.fx.timer(he.extend(u, { elem: e, anim: l, queue: l.opts.queue })), l;
	}
	function U(e) {
		return (e.match(Ee) || []).join(" ");
	}
	function z(e) {
		return (e.getAttribute && e.getAttribute("class")) || "";
	}
	function V(e) {
		return Array.isArray(e) ? e : ("string" == typeof e && e.match(Ee)) || [];
	}
	function X(e, t, n, i) {
		var o;
		if (Array.isArray(t))
			he.each(t, function (t, r) {
				n || Nt.test(e) ? i(e, r) : X(e + "[" + ("object" == typeof r && null != r ? t : "") + "]", r, n, i);
			});
		else if (n || "object" !== r(t)) i(e, t);
		else for (o in t) X(e + "[" + o + "]", t[o], n, i);
	}
	function G(e) {
		return function (t, n) {
			"string" != typeof t && ((n = t), (t = "*"));
			var r,
				i = 0,
				o = t.toLowerCase().match(Ee) || [];
			if (le(n)) for (; (r = o[i++]); ) "+" === r[0] ? ((r = r.slice(1) || "*"), (e[r] = e[r] || []).unshift(n)) : (e[r] = e[r] || []).push(n);
		};
	}
	function Y(e, t, n, r) {
		function i(a) {
			var u;
			return (
				(o[a] = !0),
				he.each(e[a] || [], function (e, a) {
					var l = a(t, n, r);
					return "string" != typeof l || s || o[l] ? (s ? !(u = l) : void 0) : (t.dataTypes.unshift(l), i(l), !1);
				}),
				u
			);
		}
		var o = {},
			s = e === Ft;
		return i(t.dataTypes[0]) || (!o["*"] && i("*"));
	}
	function Q(e, t) {
		var n,
			r,
			i = he.ajaxSettings.flatOptions || {};
		for (n in t) void 0 !== t[n] && ((i[n] ? e : r || (r = {}))[n] = t[n]);
		return r && he.extend(!0, e, r), e;
	}
	var J = [],
		K = Object.getPrototypeOf,
		Z = J.slice,
		ee = J.flat
			? function (e) {
					return J.flat.call(e);
			  }
			: function (e) {
					return J.concat.apply([], e);
			  },
		te = J.push,
		ne = J.indexOf,
		re = {},
		ie = re.toString,
		oe = re.hasOwnProperty,
		se = oe.toString,
		ae = se.call(Object),
		ue = {},
		le = function (e) {
			return "function" == typeof e && "number" != typeof e.nodeType;
		},
		ce = function (e) {
			return null != e && e === e.window;
		},
		fe = e.document,
		pe = { type: !0, src: !0, nonce: !0, noModule: !0 },
		de = "3.5.1",
		he = function (e, t) {
			return new he.fn.init(e, t);
		};
	(he.fn = he.prototype = {
		jquery: de,
		constructor: he,
		length: 0,
		toArray: function () {
			return Z.call(this);
		},
		get: function (e) {
			return null == e ? Z.call(this) : e < 0 ? this[e + this.length] : this[e];
		},
		pushStack: function (e) {
			var t = he.merge(this.constructor(), e);
			return (t.prevObject = this), t;
		},
		each: function (e) {
			return he.each(this, e);
		},
		map: function (e) {
			return this.pushStack(
				he.map(this, function (t, n) {
					return e.call(t, n, t);
				})
			);
		},
		slice: function () {
			return this.pushStack(Z.apply(this, arguments));
		},
		first: function () {
			return this.eq(0);
		},
		last: function () {
			return this.eq(-1);
		},
		even: function () {
			return this.pushStack(
				he.grep(this, function (e, t) {
					return (t + 1) % 2;
				})
			);
		},
		odd: function () {
			return this.pushStack(
				he.grep(this, function (e, t) {
					return t % 2;
				})
			);
		},
		eq: function (e) {
			var t = this.length,
				n = +e + (e < 0 ? t : 0);
			return this.pushStack(0 <= n && n < t ? [this[n]] : []);
		},
		end: function () {
			return this.prevObject || this.constructor();
		},
		push: te,
		sort: J.sort,
		splice: J.splice,
	}),
		(he.extend = he.fn.extend = function () {
			var e,
				t,
				n,
				r,
				i,
				o,
				s = arguments[0] || {},
				a = 1,
				u = arguments.length,
				l = !1;
			for ("boolean" == typeof s && ((l = s), (s = arguments[a] || {}), a++), "object" == typeof s || le(s) || (s = {}), a === u && ((s = this), a--); a < u; a++)
				if (null != (e = arguments[a]))
					for (t in e)
						(r = e[t]),
							"__proto__" !== t &&
								s !== r &&
								(l && r && (he.isPlainObject(r) || (i = Array.isArray(r))) ? ((n = s[t]), (o = i && !Array.isArray(n) ? [] : i || he.isPlainObject(n) ? n : {}), (i = !1), (s[t] = he.extend(l, o, r))) : void 0 !== r && (s[t] = r));
			return s;
		}),
		he.extend({
			expando: "jQuery" + (de + Math.random()).replace(/\D/g, ""),
			isReady: !0,
			error: function (e) {
				throw new Error(e);
			},
			noop: function () {},
			isPlainObject: function (e) {
				var t, n;
				return !(!e || "[object Object]" !== ie.call(e) || ((t = K(e)) && ("function" != typeof (n = oe.call(t, "constructor") && t.constructor) || se.call(n) !== ae)));
			},
			isEmptyObject: function (e) {
				var t;
				for (t in e) return !1;
				return !0;
			},
			globalEval: function (e, t, r) {
				n(e, { nonce: t && t.nonce }, r);
			},
			each: function (e, t) {
				var n,
					r = 0;
				if (i(e)) for (n = e.length; r < n && !1 !== t.call(e[r], r, e[r]); r++);
				else for (r in e) if (!1 === t.call(e[r], r, e[r])) break;
				return e;
			},
			makeArray: function (e, t) {
				var n = t || [];
				return null != e && (i(Object(e)) ? he.merge(n, "string" == typeof e ? [e] : e) : te.call(n, e)), n;
			},
			inArray: function (e, t, n) {
				return null == t ? -1 : ne.call(t, e, n);
			},
			merge: function (e, t) {
				for (var n = +t.length, r = 0, i = e.length; r < n; r++) e[i++] = t[r];
				return (e.length = i), e;
			},
			grep: function (e, t, n) {
				for (var r = [], i = 0, o = e.length, s = !n; i < o; i++) !t(e[i], i) !== s && r.push(e[i]);
				return r;
			},
			map: function (e, t, n) {
				var r,
					o,
					s = 0,
					a = [];
				if (i(e)) for (r = e.length; s < r; s++) null != (o = t(e[s], s, n)) && a.push(o);
				else for (s in e) null != (o = t(e[s], s, n)) && a.push(o);
				return ee(a);
			},
			guid: 1,
			support: ue,
		}),
		"function" == typeof Symbol && (he.fn[Symbol.iterator] = J[Symbol.iterator]),
		he.each("Boolean Number String Function Array Date RegExp Object Error Symbol".split(" "), function (e, t) {
			re["[object " + t + "]"] = t.toLowerCase();
		});
	var ge = (function (e) {
		function t(e, t, n, r) {
			var i,
				o,
				s,
				a,
				u,
				l,
				c,
				p = t && t.ownerDocument,
				h = t ? t.nodeType : 9;
			if (((n = n || []), "string" != typeof e || !e || (1 !== h && 9 !== h && 11 !== h))) return n;
			if (!r && (j(t), (t = t || L), _)) {
				if (11 !== h && (u = me.exec(e)))
					if ((i = u[1])) {
						if (9 === h) {
							if (!(s = t.getElementById(i))) return n;
							if (s.id === i) return n.push(s), n;
						} else if (p && (s = p.getElementById(i)) && H(t, s) && s.id === i) return n.push(s), n;
					} else {
						if (u[2]) return J.apply(n, t.getElementsByTagName(e)), n;
						if ((i = u[3]) && x.getElementsByClassName && t.getElementsByClassName) return J.apply(n, t.getElementsByClassName(i)), n;
					}
				if (x.qsa && !z[e + " "] && (!O || !O.test(e)) && (1 !== h || "object" !== t.nodeName.toLowerCase())) {
					if (((c = e), (p = t), 1 === h && (le.test(e) || ue.test(e)))) {
						for (((p = (ye.test(e) && f(t.parentNode)) || t) === t && x.scope) || ((a = t.getAttribute("id")) ? (a = a.replace(we, Te)) : t.setAttribute("id", (a = M))), o = (l = E(e)).length; o--; ) l[o] = (a ? "#" + a : ":scope") + " " + d(l[o]);
						c = l.join(",");
					}
					try {
						return J.apply(n, p.querySelectorAll(c)), n;
					} catch (t) {
						z(e, !0);
					} finally {
						a === M && t.removeAttribute("id");
					}
				}
			}
			return k(e.replace(se, "$1"), t, n, r);
		}
		function n() {
			var e = [];
			return function t(n, r) {
				return e.push(n + " ") > w.cacheLength && delete t[e.shift()], (t[n + " "] = r);
			};
		}
		function r(e) {
			return (e[M] = !0), e;
		}
		function i(e) {
			var t = L.createElement("fieldset");
			try {
				return !!e(t);
			} catch (e) {
				return !1;
			} finally {
				t.parentNode && t.parentNode.removeChild(t), (t = null);
			}
		}
		function o(e, t) {
			for (var n = e.split("|"), r = n.length; r--; ) w.attrHandle[n[r]] = t;
		}
		function s(e, t) {
			var n = t && e,
				r = n && 1 === e.nodeType && 1 === t.nodeType && e.sourceIndex - t.sourceIndex;
			if (r) return r;
			if (n) for (; (n = n.nextSibling); ) if (n === t) return -1;
			return e ? 1 : -1;
		}
		function a(e) {
			return function (t) {
				return "input" === t.nodeName.toLowerCase() && t.type === e;
			};
		}
		function u(e) {
			return function (t) {
				var n = t.nodeName.toLowerCase();
				return ("input" === n || "button" === n) && t.type === e;
			};
		}
		function l(e) {
			return function (t) {
				return "form" in t
					? t.parentNode && !1 === t.disabled
						? "label" in t
							? "label" in t.parentNode
								? t.parentNode.disabled === e
								: t.disabled === e
							: t.isDisabled === e || (t.isDisabled !== !e && Ee(t) === e)
						: t.disabled === e
					: "label" in t && t.disabled === e;
			};
		}
		function c(e) {
			return r(function (t) {
				return (
					(t = +t),
					r(function (n, r) {
						for (var i, o = e([], n.length, t), s = o.length; s--; ) n[(i = o[s])] && (n[i] = !(r[i] = n[i]));
					})
				);
			});
		}
		function f(e) {
			return e && void 0 !== e.getElementsByTagName && e;
		}
		function p() {}
		function d(e) {
			for (var t = 0, n = e.length, r = ""; t < n; t++) r += e[t].value;
			return r;
		}
		function h(e, t, n) {
			var r = t.dir,
				i = t.next,
				o = i || r,
				s = n && "parentNode" === o,
				a = W++;
			return t.first
				? function (t, n, i) {
						for (; (t = t[r]); ) if (1 === t.nodeType || s) return e(t, n, i);
						return !1;
				  }
				: function (t, n, u) {
						var l,
							c,
							f,
							p = [F, a];
						if (u) {
							for (; (t = t[r]); ) if ((1 === t.nodeType || s) && e(t, n, u)) return !0;
						} else
							for (; (t = t[r]); )
								if (1 === t.nodeType || s)
									if (((c = (f = t[M] || (t[M] = {}))[t.uniqueID] || (f[t.uniqueID] = {})), i && i === t.nodeName.toLowerCase())) t = t[r] || t;
									else {
										if ((l = c[o]) && l[0] === F && l[1] === a) return (p[2] = l[2]);
										if (((c[o] = p)[2] = e(t, n, u))) return !0;
									}
						return !1;
				  };
		}
		function g(e) {
			return 1 < e.length
				? function (t, n, r) {
						for (var i = e.length; i--; ) if (!e[i](t, n, r)) return !1;
						return !0;
				  }
				: e[0];
		}
		function v(e, t, n, r, i) {
			for (var o, s = [], a = 0, u = e.length, l = null != t; a < u; a++) (o = e[a]) && ((n && !n(o, r, i)) || (s.push(o), l && t.push(a)));
			return s;
		}
		function m(e, n, i, o, s, a) {
			return (
				o && !o[M] && (o = m(o)),
				s && !s[M] && (s = m(s, a)),
				r(function (r, a, u, l) {
					var c,
						f,
						p,
						d = [],
						h = [],
						g = a.length,
						m =
							r ||
							(function (e, n, r) {
								for (var i = 0, o = n.length; i < o; i++) t(e, n[i], r);
								return r;
							})(n || "*", u.nodeType ? [u] : u, []),
						y = !e || (!r && n) ? m : v(m, d, e, u, l),
						b = i ? (s || (r ? e : g || o) ? [] : a) : y;
					if ((i && i(y, b, u, l), o)) for (c = v(b, h), o(c, [], u, l), f = c.length; f--; ) (p = c[f]) && (b[h[f]] = !(y[h[f]] = p));
					if (r) {
						if (s || e) {
							if (s) {
								for (c = [], f = b.length; f--; ) (p = b[f]) && c.push((y[f] = p));
								s(null, (b = []), c, l);
							}
							for (f = b.length; f--; ) (p = b[f]) && -1 < (c = s ? Z(r, p) : d[f]) && (r[c] = !(a[c] = p));
						}
					} else (b = v(b === a ? b.splice(g, b.length) : b)), s ? s(null, a, b, l) : J.apply(a, b);
				})
			);
		}
		function y(e) {
			for (
				var t,
					n,
					r,
					i = e.length,
					o = w.relative[e[0].type],
					s = o || w.relative[" "],
					a = o ? 1 : 0,
					u = h(
						function (e) {
							return e === t;
						},
						s,
						!0
					),
					l = h(
						function (e) {
							return -1 < Z(t, e);
						},
						s,
						!0
					),
					c = [
						function (e, n, r) {
							var i = (!o && (r || n !== A)) || ((t = n).nodeType ? u(e, n, r) : l(e, n, r));
							return (t = null), i;
						},
					];
				a < i;
				a++
			)
				if ((n = w.relative[e[a].type])) c = [h(g(c), n)];
				else {
					if ((n = w.filter[e[a].type].apply(null, e[a].matches))[M]) {
						for (r = ++a; r < i && !w.relative[e[r].type]; r++);
						return m(1 < a && g(c), 1 < a && d(e.slice(0, a - 1).concat({ value: " " === e[a - 2].type ? "*" : "" })).replace(se, "$1"), n, a < r && y(e.slice(a, r)), r < i && y((e = e.slice(r))), r < i && d(e));
					}
					c.push(n);
				}
			return g(c);
		}
		var b,
			x,
			w,
			T,
			C,
			E,
			S,
			k,
			A,
			D,
			N,
			j,
			L,
			q,
			_,
			O,
			R,
			I,
			H,
			M = "sizzle" + 1 * new Date(),
			P = e.document,
			F = 0,
			W = 0,
			B = n(),
			$ = n(),
			U = n(),
			z = n(),
			V = function (e, t) {
				return e === t && (N = !0), 0;
			},
			X = {}.hasOwnProperty,
			G = [],
			Y = G.pop,
			Q = G.push,
			J = G.push,
			K = G.slice,
			Z = function (e, t) {
				for (var n = 0, r = e.length; n < r; n++) if (e[n] === t) return n;
				return -1;
			},
			ee = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
			te = "[\\x20\\t\\r\\n\\f]",
			ne = "(?:\\\\[\\da-fA-F]{1,6}" + te + "?|\\\\[^\\r\\n\\f]|[\\w-]|[^\0-\\x7f])+",
			re = "\\[" + te + "*(" + ne + ")(?:" + te + "*([*^$|!~]?=)" + te + "*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|(" + ne + "))|)" + te + "*\\]",
			ie = ":(" + ne + ")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|" + re + ")*)|.*)\\)|)",
			oe = new RegExp(te + "+", "g"),
			se = new RegExp("^" + te + "+|((?:^|[^\\\\])(?:\\\\.)*)" + te + "+$", "g"),
			ae = new RegExp("^" + te + "*," + te + "*"),
			ue = new RegExp("^" + te + "*([>+~]|" + te + ")" + te + "*"),
			le = new RegExp(te + "|>"),
			ce = new RegExp(ie),
			fe = new RegExp("^" + ne + "$"),
			pe = {
				ID: new RegExp("^#(" + ne + ")"),
				CLASS: new RegExp("^\\.(" + ne + ")"),
				TAG: new RegExp("^(" + ne + "|[*])"),
				ATTR: new RegExp("^" + re),
				PSEUDO: new RegExp("^" + ie),
				CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + te + "*(even|odd|(([+-]|)(\\d*)n|)" + te + "*(?:([+-]|)" + te + "*(\\d+)|))" + te + "*\\)|)", "i"),
				bool: new RegExp("^(?:" + ee + ")$", "i"),
				needsContext: new RegExp("^" + te + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + te + "*((?:-\\d)?\\d*)" + te + "*\\)|)(?=[^-]|$)", "i"),
			},
			de = /HTML$/i,
			he = /^(?:input|select|textarea|button)$/i,
			ge = /^h\d$/i,
			ve = /^[^{]+\{\s*\[native \w/,
			me = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
			ye = /[+~]/,
			be = new RegExp("\\\\[\\da-fA-F]{1,6}" + te + "?|\\\\([^\\r\\n\\f])", "g"),
			xe = function (e, t) {
				var n = "0x" + e.slice(1) - 65536;
				return t || (n < 0 ? String.fromCharCode(n + 65536) : String.fromCharCode((n >> 10) | 55296, (1023 & n) | 56320));
			},
			we = /([\0-\x1f\x7f]|^-?\d)|^-$|[^\0-\x1f\x7f-\uFFFF\w-]/g,
			Te = function (e, t) {
				return t ? ("\0" === e ? "�" : e.slice(0, -1) + "\\" + e.charCodeAt(e.length - 1).toString(16) + " ") : "\\" + e;
			},
			Ce = function () {
				j();
			},
			Ee = h(
				function (e) {
					return !0 === e.disabled && "fieldset" === e.nodeName.toLowerCase();
				},
				{ dir: "parentNode", next: "legend" }
			);
		try {
			J.apply((G = K.call(P.childNodes)), P.childNodes), G[P.childNodes.length].nodeType;
		} catch (b) {
			J = {
				apply: G.length
					? function (e, t) {
							Q.apply(e, K.call(t));
					  }
					: function (e, t) {
							for (var n = e.length, r = 0; (e[n++] = t[r++]); );
							e.length = n - 1;
					  },
			};
		}
		for (b in ((x = t.support = {}),
		(C = t.isXML = function (e) {
			var t = e.namespaceURI,
				n = (e.ownerDocument || e).documentElement;
			return !de.test(t || (n && n.nodeName) || "HTML");
		}),
		(j = t.setDocument = function (e) {
			var t,
				n,
				r = e ? e.ownerDocument || e : P;
			return (
				r != L &&
					9 === r.nodeType &&
					r.documentElement &&
					((q = (L = r).documentElement),
					(_ = !C(L)),
					P != L && (n = L.defaultView) && n.top !== n && (n.addEventListener ? n.addEventListener("unload", Ce, !1) : n.attachEvent && n.attachEvent("onunload", Ce)),
					(x.scope = i(function (e) {
						return q.appendChild(e).appendChild(L.createElement("div")), void 0 !== e.querySelectorAll && !e.querySelectorAll(":scope fieldset div").length;
					})),
					(x.attributes = i(function (e) {
						return (e.className = "i"), !e.getAttribute("className");
					})),
					(x.getElementsByTagName = i(function (e) {
						return e.appendChild(L.createComment("")), !e.getElementsByTagName("*").length;
					})),
					(x.getElementsByClassName = ve.test(L.getElementsByClassName)),
					(x.getById = i(function (e) {
						return (q.appendChild(e).id = M), !L.getElementsByName || !L.getElementsByName(M).length;
					})),
					x.getById
						? ((w.filter.ID = function (e) {
								var t = e.replace(be, xe);
								return function (e) {
									return e.getAttribute("id") === t;
								};
						  }),
						  (w.find.ID = function (e, t) {
								if (void 0 !== t.getElementById && _) {
									var n = t.getElementById(e);
									return n ? [n] : [];
								}
						  }))
						: ((w.filter.ID = function (e) {
								var t = e.replace(be, xe);
								return function (e) {
									var n = void 0 !== e.getAttributeNode && e.getAttributeNode("id");
									return n && n.value === t;
								};
						  }),
						  (w.find.ID = function (e, t) {
								if (void 0 !== t.getElementById && _) {
									var n,
										r,
										i,
										o = t.getElementById(e);
									if (o) {
										if ((n = o.getAttributeNode("id")) && n.value === e) return [o];
										for (i = t.getElementsByName(e), r = 0; (o = i[r++]); ) if ((n = o.getAttributeNode("id")) && n.value === e) return [o];
									}
									return [];
								}
						  })),
					(w.find.TAG = x.getElementsByTagName
						? function (e, t) {
								return void 0 !== t.getElementsByTagName ? t.getElementsByTagName(e) : x.qsa ? t.querySelectorAll(e) : void 0;
						  }
						: function (e, t) {
								var n,
									r = [],
									i = 0,
									o = t.getElementsByTagName(e);
								if ("*" === e) {
									for (; (n = o[i++]); ) 1 === n.nodeType && r.push(n);
									return r;
								}
								return o;
						  }),
					(w.find.CLASS =
						x.getElementsByClassName &&
						function (e, t) {
							if (void 0 !== t.getElementsByClassName && _) return t.getElementsByClassName(e);
						}),
					(R = []),
					(O = []),
					(x.qsa = ve.test(L.querySelectorAll)) &&
						(i(function (e) {
							var t;
							(q.appendChild(e).innerHTML = "<a id='" + M + "'></a><select id='" + M + "-\r\\' msallowcapture=''><option selected=''></option></select>"),
								e.querySelectorAll("[msallowcapture^='']").length && O.push("[*^$]=" + te + "*(?:''|\"\")"),
								e.querySelectorAll("[selected]").length || O.push("\\[" + te + "*(?:value|" + ee + ")"),
								e.querySelectorAll("[id~=" + M + "-]").length || O.push("~="),
								(t = L.createElement("input")).setAttribute("name", ""),
								e.appendChild(t),
								e.querySelectorAll("[name='']").length || O.push("\\[" + te + "*name" + te + "*=" + te + "*(?:''|\"\")"),
								e.querySelectorAll(":checked").length || O.push(":checked"),
								e.querySelectorAll("a#" + M + "+*").length || O.push(".#.+[+~]"),
								e.querySelectorAll("\\\f"),
								O.push("[\\r\\n\\f]");
						}),
						i(function (e) {
							e.innerHTML = "<a href='' disabled='disabled'></a><select disabled='disabled'><option/></select>";
							var t = L.createElement("input");
							t.setAttribute("type", "hidden"),
								e.appendChild(t).setAttribute("name", "D"),
								e.querySelectorAll("[name=d]").length && O.push("name" + te + "*[*^$|!~]?="),
								2 !== e.querySelectorAll(":enabled").length && O.push(":enabled", ":disabled"),
								(q.appendChild(e).disabled = !0),
								2 !== e.querySelectorAll(":disabled").length && O.push(":enabled", ":disabled"),
								e.querySelectorAll("*,:x"),
								O.push(",.*:");
						})),
					(x.matchesSelector = ve.test((I = q.matches || q.webkitMatchesSelector || q.mozMatchesSelector || q.oMatchesSelector || q.msMatchesSelector))) &&
						i(function (e) {
							(x.disconnectedMatch = I.call(e, "*")), I.call(e, "[s!='']:x"), R.push("!=", ie);
						}),
					(O = O.length && new RegExp(O.join("|"))),
					(R = R.length && new RegExp(R.join("|"))),
					(t = ve.test(q.compareDocumentPosition)),
					(H =
						t || ve.test(q.contains)
							? function (e, t) {
									var n = 9 === e.nodeType ? e.documentElement : e,
										r = t && t.parentNode;
									return e === r || !(!r || 1 !== r.nodeType || !(n.contains ? n.contains(r) : e.compareDocumentPosition && 16 & e.compareDocumentPosition(r)));
							  }
							: function (e, t) {
									if (t) for (; (t = t.parentNode); ) if (t === e) return !0;
									return !1;
							  }),
					(V = t
						? function (e, t) {
								if (e === t) return (N = !0), 0;
								var n = !e.compareDocumentPosition - !t.compareDocumentPosition;
								return (
									n ||
									(1 & (n = (e.ownerDocument || e) == (t.ownerDocument || t) ? e.compareDocumentPosition(t) : 1) || (!x.sortDetached && t.compareDocumentPosition(e) === n)
										? e == L || (e.ownerDocument == P && H(P, e))
											? -1
											: t == L || (t.ownerDocument == P && H(P, t))
											? 1
											: D
											? Z(D, e) - Z(D, t)
											: 0
										: 4 & n
										? -1
										: 1)
								);
						  }
						: function (e, t) {
								if (e === t) return (N = !0), 0;
								var n,
									r = 0,
									i = e.parentNode,
									o = t.parentNode,
									a = [e],
									u = [t];
								if (!i || !o) return e == L ? -1 : t == L ? 1 : i ? -1 : o ? 1 : D ? Z(D, e) - Z(D, t) : 0;
								if (i === o) return s(e, t);
								for (n = e; (n = n.parentNode); ) a.unshift(n);
								for (n = t; (n = n.parentNode); ) u.unshift(n);
								for (; a[r] === u[r]; ) r++;
								return r ? s(a[r], u[r]) : a[r] == P ? -1 : u[r] == P ? 1 : 0;
						  })),
				L
			);
		}),
		(t.matches = function (e, n) {
			return t(e, null, null, n);
		}),
		(t.matchesSelector = function (e, n) {
			if ((j(e), x.matchesSelector && _ && !z[n + " "] && (!R || !R.test(n)) && (!O || !O.test(n))))
				try {
					var r = I.call(e, n);
					if (r || x.disconnectedMatch || (e.document && 11 !== e.document.nodeType)) return r;
				} catch (e) {
					z(n, !0);
				}
			return 0 < t(n, L, null, [e]).length;
		}),
		(t.contains = function (e, t) {
			return (e.ownerDocument || e) != L && j(e), H(e, t);
		}),
		(t.attr = function (e, t) {
			(e.ownerDocument || e) != L && j(e);
			var n = w.attrHandle[t.toLowerCase()],
				r = n && X.call(w.attrHandle, t.toLowerCase()) ? n(e, t, !_) : void 0;
			return void 0 !== r ? r : x.attributes || !_ ? e.getAttribute(t) : (r = e.getAttributeNode(t)) && r.specified ? r.value : null;
		}),
		(t.escape = function (e) {
			return (e + "").replace(we, Te);
		}),
		(t.error = function (e) {
			throw new Error("Syntax error, unrecognized expression: " + e);
		}),
		(t.uniqueSort = function (e) {
			var t,
				n = [],
				r = 0,
				i = 0;
			if (((N = !x.detectDuplicates), (D = !x.sortStable && e.slice(0)), e.sort(V), N)) {
				for (; (t = e[i++]); ) t === e[i] && (r = n.push(i));
				for (; r--; ) e.splice(n[r], 1);
			}
			return (D = null), e;
		}),
		(T = t.getText = function (e) {
			var t,
				n = "",
				r = 0,
				i = e.nodeType;
			if (i) {
				if (1 === i || 9 === i || 11 === i) {
					if ("string" == typeof e.textContent) return e.textContent;
					for (e = e.firstChild; e; e = e.nextSibling) n += T(e);
				} else if (3 === i || 4 === i) return e.nodeValue;
			} else for (; (t = e[r++]); ) n += T(t);
			return n;
		}),
		((w = t.selectors = {
			cacheLength: 50,
			createPseudo: r,
			match: pe,
			attrHandle: {},
			find: {},
			relative: { ">": { dir: "parentNode", first: !0 }, " ": { dir: "parentNode" }, "+": { dir: "previousSibling", first: !0 }, "~": { dir: "previousSibling" } },
			preFilter: {
				ATTR: function (e) {
					return (e[1] = e[1].replace(be, xe)), (e[3] = (e[3] || e[4] || e[5] || "").replace(be, xe)), "~=" === e[2] && (e[3] = " " + e[3] + " "), e.slice(0, 4);
				},
				CHILD: function (e) {
					return (e[1] = e[1].toLowerCase()), "nth" === e[1].slice(0, 3) ? (e[3] || t.error(e[0]), (e[4] = +(e[4] ? e[5] + (e[6] || 1) : 2 * ("even" === e[3] || "odd" === e[3]))), (e[5] = +(e[7] + e[8] || "odd" === e[3]))) : e[3] && t.error(e[0]), e;
				},
				PSEUDO: function (e) {
					var t,
						n = !e[6] && e[2];
					return pe.CHILD.test(e[0]) ? null : (e[3] ? (e[2] = e[4] || e[5] || "") : n && ce.test(n) && (t = E(n, !0)) && (t = n.indexOf(")", n.length - t) - n.length) && ((e[0] = e[0].slice(0, t)), (e[2] = n.slice(0, t))), e.slice(0, 3));
				},
			},
			filter: {
				TAG: function (e) {
					var t = e.replace(be, xe).toLowerCase();
					return "*" === e
						? function () {
								return !0;
						  }
						: function (e) {
								return e.nodeName && e.nodeName.toLowerCase() === t;
						  };
				},
				CLASS: function (e) {
					var t = B[e + " "];
					return (
						t ||
						((t = new RegExp("(^|" + te + ")" + e + "(" + te + "|$)")) &&
							B(e, function (e) {
								return t.test(("string" == typeof e.className && e.className) || (void 0 !== e.getAttribute && e.getAttribute("class")) || "");
							}))
					);
				},
				ATTR: function (e, n, r) {
					return function (i) {
						var o = t.attr(i, e);
						return null == o
							? "!=" === n
							: !n ||
									((o += ""),
									"=" === n
										? o === r
										: "!=" === n
										? o !== r
										: "^=" === n
										? r && 0 === o.indexOf(r)
										: "*=" === n
										? r && -1 < o.indexOf(r)
										: "$=" === n
										? r && o.slice(-r.length) === r
										: "~=" === n
										? -1 < (" " + o.replace(oe, " ") + " ").indexOf(r)
										: "|=" === n && (o === r || o.slice(0, r.length + 1) === r + "-"));
					};
				},
				CHILD: function (e, t, n, r, i) {
					var o = "nth" !== e.slice(0, 3),
						s = "last" !== e.slice(-4),
						a = "of-type" === t;
					return 1 === r && 0 === i
						? function (e) {
								return !!e.parentNode;
						  }
						: function (t, n, u) {
								var l,
									c,
									f,
									p,
									d,
									h,
									g = o !== s ? "nextSibling" : "previousSibling",
									v = t.parentNode,
									m = a && t.nodeName.toLowerCase(),
									y = !u && !a,
									b = !1;
								if (v) {
									if (o) {
										for (; g; ) {
											for (p = t; (p = p[g]); ) if (a ? p.nodeName.toLowerCase() === m : 1 === p.nodeType) return !1;
											h = g = "only" === e && !h && "nextSibling";
										}
										return !0;
									}
									if (((h = [s ? v.firstChild : v.lastChild]), s && y)) {
										for (b = (d = (l = (c = (f = (p = v)[M] || (p[M] = {}))[p.uniqueID] || (f[p.uniqueID] = {}))[e] || [])[0] === F && l[1]) && l[2], p = d && v.childNodes[d]; (p = (++d && p && p[g]) || (b = d = 0) || h.pop()); )
											if (1 === p.nodeType && ++b && p === t) {
												c[e] = [F, d, b];
												break;
											}
									} else if ((y && (b = d = (l = (c = (f = (p = t)[M] || (p[M] = {}))[p.uniqueID] || (f[p.uniqueID] = {}))[e] || [])[0] === F && l[1]), !1 === b))
										for (
											;
											(p = (++d && p && p[g]) || (b = d = 0) || h.pop()) && ((a ? p.nodeName.toLowerCase() !== m : 1 !== p.nodeType) || !++b || (y && ((c = (f = p[M] || (p[M] = {}))[p.uniqueID] || (f[p.uniqueID] = {}))[e] = [F, b]), p !== t));

										);
									return (b -= i) === r || (b % r == 0 && 0 <= b / r);
								}
						  };
				},
				PSEUDO: function (e, n) {
					var i,
						o = w.pseudos[e] || w.setFilters[e.toLowerCase()] || t.error("unsupported pseudo: " + e);
					return o[M]
						? o(n)
						: 1 < o.length
						? ((i = [e, e, "", n]),
						  w.setFilters.hasOwnProperty(e.toLowerCase())
								? r(function (e, t) {
										for (var r, i = o(e, n), s = i.length; s--; ) e[(r = Z(e, i[s]))] = !(t[r] = i[s]);
								  })
								: function (e) {
										return o(e, 0, i);
								  })
						: o;
				},
			},
			pseudos: {
				not: r(function (e) {
					var t = [],
						n = [],
						i = S(e.replace(se, "$1"));
					return i[M]
						? r(function (e, t, n, r) {
								for (var o, s = i(e, null, r, []), a = e.length; a--; ) (o = s[a]) && (e[a] = !(t[a] = o));
						  })
						: function (e, r, o) {
								return (t[0] = e), i(t, null, o, n), (t[0] = null), !n.pop();
						  };
				}),
				has: r(function (e) {
					return function (n) {
						return 0 < t(e, n).length;
					};
				}),
				contains: r(function (e) {
					return (
						(e = e.replace(be, xe)),
						function (t) {
							return -1 < (t.textContent || T(t)).indexOf(e);
						}
					);
				}),
				lang: r(function (e) {
					return (
						fe.test(e || "") || t.error("unsupported lang: " + e),
						(e = e.replace(be, xe).toLowerCase()),
						function (t) {
							var n;
							do {
								if ((n = _ ? t.lang : t.getAttribute("xml:lang") || t.getAttribute("lang"))) return (n = n.toLowerCase()) === e || 0 === n.indexOf(e + "-");
							} while ((t = t.parentNode) && 1 === t.nodeType);
							return !1;
						}
					);
				}),
				target: function (t) {
					var n = e.location && e.location.hash;
					return n && n.slice(1) === t.id;
				},
				root: function (e) {
					return e === q;
				},
				focus: function (e) {
					return e === L.activeElement && (!L.hasFocus || L.hasFocus()) && !!(e.type || e.href || ~e.tabIndex);
				},
				enabled: l(!1),
				disabled: l(!0),
				checked: function (e) {
					var t = e.nodeName.toLowerCase();
					return ("input" === t && !!e.checked) || ("option" === t && !!e.selected);
				},
				selected: function (e) {
					return e.parentNode && e.parentNode.selectedIndex, !0 === e.selected;
				},
				empty: function (e) {
					for (e = e.firstChild; e; e = e.nextSibling) if (e.nodeType < 6) return !1;
					return !0;
				},
				parent: function (e) {
					return !w.pseudos.empty(e);
				},
				header: function (e) {
					return ge.test(e.nodeName);
				},
				input: function (e) {
					return he.test(e.nodeName);
				},
				button: function (e) {
					var t = e.nodeName.toLowerCase();
					return ("input" === t && "button" === e.type) || "button" === t;
				},
				text: function (e) {
					var t;
					return "input" === e.nodeName.toLowerCase() && "text" === e.type && (null == (t = e.getAttribute("type")) || "text" === t.toLowerCase());
				},
				first: c(function () {
					return [0];
				}),
				last: c(function (e, t) {
					return [t - 1];
				}),
				eq: c(function (e, t, n) {
					return [n < 0 ? n + t : n];
				}),
				even: c(function (e, t) {
					for (var n = 0; n < t; n += 2) e.push(n);
					return e;
				}),
				odd: c(function (e, t) {
					for (var n = 1; n < t; n += 2) e.push(n);
					return e;
				}),
				lt: c(function (e, t, n) {
					for (var r = n < 0 ? n + t : t < n ? t : n; 0 <= --r; ) e.push(r);
					return e;
				}),
				gt: c(function (e, t, n) {
					for (var r = n < 0 ? n + t : n; ++r < t; ) e.push(r);
					return e;
				}),
			},
		}).pseudos.nth = w.pseudos.eq),
		{ radio: !0, checkbox: !0, file: !0, password: !0, image: !0 }))
			w.pseudos[b] = a(b);
		for (b in { submit: !0, reset: !0 }) w.pseudos[b] = u(b);
		return (
			(p.prototype = w.filters = w.pseudos),
			(w.setFilters = new p()),
			(E = t.tokenize = function (e, n) {
				var r,
					i,
					o,
					s,
					a,
					u,
					l,
					c = $[e + " "];
				if (c) return n ? 0 : c.slice(0);
				for (a = e, u = [], l = w.preFilter; a; ) {
					for (s in ((r && !(i = ae.exec(a))) || (i && (a = a.slice(i[0].length) || a), u.push((o = []))), (r = !1), (i = ue.exec(a)) && ((r = i.shift()), o.push({ value: r, type: i[0].replace(se, " ") }), (a = a.slice(r.length))), w.filter))
						!(i = pe[s].exec(a)) || (l[s] && !(i = l[s](i))) || ((r = i.shift()), o.push({ value: r, type: s, matches: i }), (a = a.slice(r.length)));
					if (!r) break;
				}
				return n ? a.length : a ? t.error(e) : $(e, u).slice(0);
			}),
			(S = t.compile = function (e, n) {
				var i,
					o,
					s,
					a,
					u,
					l,
					c = [],
					f = [],
					p = U[e + " "];
				if (!p) {
					for (n || (n = E(e)), i = n.length; i--; ) (p = y(n[i]))[M] ? c.push(p) : f.push(p);
					(p = U(
						e,
						((o = f),
						(a = 0 < (s = c).length),
						(u = 0 < o.length),
						(l = function (e, n, r, i, l) {
							var c,
								f,
								p,
								d = 0,
								h = "0",
								g = e && [],
								m = [],
								y = A,
								b = e || (u && w.find.TAG("*", l)),
								x = (F += null == y ? 1 : Math.random() || 0.1),
								T = b.length;
							for (l && (A = n == L || n || l); h !== T && null != (c = b[h]); h++) {
								if (u && c) {
									for (f = 0, n || c.ownerDocument == L || (j(c), (r = !_)); (p = o[f++]); )
										if (p(c, n || L, r)) {
											i.push(c);
											break;
										}
									l && (F = x);
								}
								a && ((c = !p && c) && d--, e && g.push(c));
							}
							if (((d += h), a && h !== d)) {
								for (f = 0; (p = s[f++]); ) p(g, m, n, r);
								if (e) {
									if (0 < d) for (; h--; ) g[h] || m[h] || (m[h] = Y.call(i));
									m = v(m);
								}
								J.apply(i, m), l && !e && 0 < m.length && 1 < d + s.length && t.uniqueSort(i);
							}
							return l && ((F = x), (A = y)), g;
						}),
						a ? r(l) : l)
					)).selector = e;
				}
				return p;
			}),
			(k = t.select = function (e, t, n, r) {
				var i,
					o,
					s,
					a,
					u,
					l = "function" == typeof e && e,
					c = !r && E((e = l.selector || e));
				if (((n = n || []), 1 === c.length)) {
					if (2 < (o = c[0] = c[0].slice(0)).length && "ID" === (s = o[0]).type && 9 === t.nodeType && _ && w.relative[o[1].type]) {
						if (!(t = (w.find.ID(s.matches[0].replace(be, xe), t) || [])[0])) return n;
						l && (t = t.parentNode), (e = e.slice(o.shift().value.length));
					}
					for (i = pe.needsContext.test(e) ? 0 : o.length; i-- && ((s = o[i]), !w.relative[(a = s.type)]); )
						if ((u = w.find[a]) && (r = u(s.matches[0].replace(be, xe), (ye.test(o[0].type) && f(t.parentNode)) || t))) {
							if ((o.splice(i, 1), !(e = r.length && d(o)))) return J.apply(n, r), n;
							break;
						}
				}
				return (l || S(e, c))(r, t, !_, n, !t || (ye.test(e) && f(t.parentNode)) || t), n;
			}),
			(x.sortStable = M.split("").sort(V).join("") === M),
			(x.detectDuplicates = !!N),
			j(),
			(x.sortDetached = i(function (e) {
				return 1 & e.compareDocumentPosition(L.createElement("fieldset"));
			})),
			i(function (e) {
				return (e.innerHTML = "<a href='#'></a>"), "#" === e.firstChild.getAttribute("href");
			}) ||
				o("type|href|height|width", function (e, t, n) {
					if (!n) return e.getAttribute(t, "type" === t.toLowerCase() ? 1 : 2);
				}),
			(x.attributes &&
				i(function (e) {
					return (e.innerHTML = "<input/>"), e.firstChild.setAttribute("value", ""), "" === e.firstChild.getAttribute("value");
				})) ||
				o("value", function (e, t, n) {
					if (!n && "input" === e.nodeName.toLowerCase()) return e.defaultValue;
				}),
			i(function (e) {
				return null == e.getAttribute("disabled");
			}) ||
				o(ee, function (e, t, n) {
					var r;
					if (!n) return !0 === e[t] ? t.toLowerCase() : (r = e.getAttributeNode(t)) && r.specified ? r.value : null;
				}),
			t
		);
	})(e);
	(he.find = ge), (he.expr = ge.selectors), (he.expr[":"] = he.expr.pseudos), (he.uniqueSort = he.unique = ge.uniqueSort), (he.text = ge.getText), (he.isXMLDoc = ge.isXML), (he.contains = ge.contains), (he.escapeSelector = ge.escape);
	var ve = function (e, t, n) {
			for (var r = [], i = void 0 !== n; (e = e[t]) && 9 !== e.nodeType; )
				if (1 === e.nodeType) {
					if (i && he(e).is(n)) break;
					r.push(e);
				}
			return r;
		},
		me = function (e, t) {
			for (var n = []; e; e = e.nextSibling) 1 === e.nodeType && e !== t && n.push(e);
			return n;
		},
		ye = he.expr.match.needsContext,
		be = /^<([a-z][^\/\0>:\x20\t\r\n\f]*)[\x20\t\r\n\f]*\/?>(?:<\/\1>|)$/i;
	(he.filter = function (e, t, n) {
		var r = t[0];
		return (
			n && (e = ":not(" + e + ")"),
			1 === t.length && 1 === r.nodeType
				? he.find.matchesSelector(r, e)
					? [r]
					: []
				: he.find.matches(
						e,
						he.grep(t, function (e) {
							return 1 === e.nodeType;
						})
				  )
		);
	}),
		he.fn.extend({
			find: function (e) {
				var t,
					n,
					r = this.length,
					i = this;
				if ("string" != typeof e)
					return this.pushStack(
						he(e).filter(function () {
							for (t = 0; t < r; t++) if (he.contains(i[t], this)) return !0;
						})
					);
				for (n = this.pushStack([]), t = 0; t < r; t++) he.find(e, i[t], n);
				return 1 < r ? he.uniqueSort(n) : n;
			},
			filter: function (e) {
				return this.pushStack(s(this, e || [], !1));
			},
			not: function (e) {
				return this.pushStack(s(this, e || [], !0));
			},
			is: function (e) {
				return !!s(this, "string" == typeof e && ye.test(e) ? he(e) : e || [], !1).length;
			},
		});
	var xe,
		we = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]+))$/;
	((he.fn.init = function (e, t, n) {
		var r, i;
		if (!e) return this;
		if (((n = n || xe), "string" == typeof e)) {
			if (!(r = "<" === e[0] && ">" === e[e.length - 1] && 3 <= e.length ? [null, e, null] : we.exec(e)) || (!r[1] && t)) return !t || t.jquery ? (t || n).find(e) : this.constructor(t).find(e);
			if (r[1]) {
				if (((t = t instanceof he ? t[0] : t), he.merge(this, he.parseHTML(r[1], t && t.nodeType ? t.ownerDocument || t : fe, !0)), be.test(r[1]) && he.isPlainObject(t))) for (r in t) le(this[r]) ? this[r](t[r]) : this.attr(r, t[r]);
				return this;
			}
			return (i = fe.getElementById(r[2])) && ((this[0] = i), (this.length = 1)), this;
		}
		return e.nodeType ? ((this[0] = e), (this.length = 1), this) : le(e) ? (void 0 !== n.ready ? n.ready(e) : e(he)) : he.makeArray(e, this);
	}).prototype = he.fn),
		(xe = he(fe));
	var Te = /^(?:parents|prev(?:Until|All))/,
		Ce = { children: !0, contents: !0, next: !0, prev: !0 };
	he.fn.extend({
		has: function (e) {
			var t = he(e, this),
				n = t.length;
			return this.filter(function () {
				for (var e = 0; e < n; e++) if (he.contains(this, t[e])) return !0;
			});
		},
		closest: function (e, t) {
			var n,
				r = 0,
				i = this.length,
				o = [],
				s = "string" != typeof e && he(e);
			if (!ye.test(e))
				for (; r < i; r++)
					for (n = this[r]; n && n !== t; n = n.parentNode)
						if (n.nodeType < 11 && (s ? -1 < s.index(n) : 1 === n.nodeType && he.find.matchesSelector(n, e))) {
							o.push(n);
							break;
						}
			return this.pushStack(1 < o.length ? he.uniqueSort(o) : o);
		},
		index: function (e) {
			return e ? ("string" == typeof e ? ne.call(he(e), this[0]) : ne.call(this, e.jquery ? e[0] : e)) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1;
		},
		add: function (e, t) {
			return this.pushStack(he.uniqueSort(he.merge(this.get(), he(e, t))));
		},
		addBack: function (e) {
			return this.add(null == e ? this.prevObject : this.prevObject.filter(e));
		},
	}),
		he.each(
			{
				parent: function (e) {
					var t = e.parentNode;
					return t && 11 !== t.nodeType ? t : null;
				},
				parents: function (e) {
					return ve(e, "parentNode");
				},
				parentsUntil: function (e, t, n) {
					return ve(e, "parentNode", n);
				},
				next: function (e) {
					return a(e, "nextSibling");
				},
				prev: function (e) {
					return a(e, "previousSibling");
				},
				nextAll: function (e) {
					return ve(e, "nextSibling");
				},
				prevAll: function (e) {
					return ve(e, "previousSibling");
				},
				nextUntil: function (e, t, n) {
					return ve(e, "nextSibling", n);
				},
				prevUntil: function (e, t, n) {
					return ve(e, "previousSibling", n);
				},
				siblings: function (e) {
					return me((e.parentNode || {}).firstChild, e);
				},
				children: function (e) {
					return me(e.firstChild);
				},
				contents: function (e) {
					return null != e.contentDocument && K(e.contentDocument) ? e.contentDocument : (o(e, "template") && (e = e.content || e), he.merge([], e.childNodes));
				},
			},
			function (e, t) {
				he.fn[e] = function (n, r) {
					var i = he.map(this, t, n);
					return "Until" !== e.slice(-5) && (r = n), r && "string" == typeof r && (i = he.filter(r, i)), 1 < this.length && (Ce[e] || he.uniqueSort(i), Te.test(e) && i.reverse()), this.pushStack(i);
				};
			}
		);
	var Ee = /[^\x20\t\r\n\f]+/g;
	(he.Callbacks = function (e) {
		var t, n;
		e =
			"string" == typeof e
				? ((t = e),
				  (n = {}),
				  he.each(t.match(Ee) || [], function (e, t) {
						n[t] = !0;
				  }),
				  n)
				: he.extend({}, e);
		var i,
			o,
			s,
			a,
			u = [],
			l = [],
			c = -1,
			f = function () {
				for (a = a || e.once, s = i = !0; l.length; c = -1) for (o = l.shift(); ++c < u.length; ) !1 === u[c].apply(o[0], o[1]) && e.stopOnFalse && ((c = u.length), (o = !1));
				e.memory || (o = !1), (i = !1), a && (u = o ? [] : "");
			},
			p = {
				add: function () {
					return (
						u &&
							(o && !i && ((c = u.length - 1), l.push(o)),
							(function t(n) {
								he.each(n, function (n, i) {
									le(i) ? (e.unique && p.has(i)) || u.push(i) : i && i.length && "string" !== r(i) && t(i);
								});
							})(arguments),
							o && !i && f()),
						this
					);
				},
				remove: function () {
					return (
						he.each(arguments, function (e, t) {
							for (var n; -1 < (n = he.inArray(t, u, n)); ) u.splice(n, 1), n <= c && c--;
						}),
						this
					);
				},
				has: function (e) {
					return e ? -1 < he.inArray(e, u) : 0 < u.length;
				},
				empty: function () {
					return u && (u = []), this;
				},
				disable: function () {
					return (a = l = []), (u = o = ""), this;
				},
				disabled: function () {
					return !u;
				},
				lock: function () {
					return (a = l = []), o || i || (u = o = ""), this;
				},
				locked: function () {
					return !!a;
				},
				fireWith: function (e, t) {
					return a || ((t = [e, (t = t || []).slice ? t.slice() : t]), l.push(t), i || f()), this;
				},
				fire: function () {
					return p.fireWith(this, arguments), this;
				},
				fired: function () {
					return !!s;
				},
			};
		return p;
	}),
		he.extend({
			Deferred: function (t) {
				var n = [
						["notify", "progress", he.Callbacks("memory"), he.Callbacks("memory"), 2],
						["resolve", "done", he.Callbacks("once memory"), he.Callbacks("once memory"), 0, "resolved"],
						["reject", "fail", he.Callbacks("once memory"), he.Callbacks("once memory"), 1, "rejected"],
					],
					r = "pending",
					i = {
						state: function () {
							return r;
						},
						always: function () {
							return o.done(arguments).fail(arguments), this;
						},
						catch: function (e) {
							return i.then(null, e);
						},
						pipe: function () {
							var e = arguments;
							return he
								.Deferred(function (t) {
									he.each(n, function (n, r) {
										var i = le(e[r[4]]) && e[r[4]];
										o[r[1]](function () {
											var e = i && i.apply(this, arguments);
											e && le(e.promise) ? e.promise().progress(t.notify).done(t.resolve).fail(t.reject) : t[r[0] + "With"](this, i ? [e] : arguments);
										});
									}),
										(e = null);
								})
								.promise();
						},
						then: function (t, r, i) {
							function o(t, n, r, i) {
								return function () {
									var a = this,
										c = arguments,
										f = function () {
											var e, f;
											if (!(t < s)) {
												if ((e = r.apply(a, c)) === n.promise()) throw new TypeError("Thenable self-resolution");
												(f = e && ("object" == typeof e || "function" == typeof e) && e.then),
													le(f) ? (i ? f.call(e, o(s, n, u, i), o(s, n, l, i)) : (s++, f.call(e, o(s, n, u, i), o(s, n, l, i), o(s, n, u, n.notifyWith)))) : (r !== u && ((a = void 0), (c = [e])), (i || n.resolveWith)(a, c));
											}
										},
										p = i
											? f
											: function () {
													try {
														f();
													} catch (e) {
														he.Deferred.exceptionHook && he.Deferred.exceptionHook(e, p.stackTrace), s <= t + 1 && (r !== l && ((a = void 0), (c = [e])), n.rejectWith(a, c));
													}
											  };
									t ? p() : (he.Deferred.getStackHook && (p.stackTrace = he.Deferred.getStackHook()), e.setTimeout(p));
								};
							}
							var s = 0;
							return he
								.Deferred(function (e) {
									n[0][3].add(o(0, e, le(i) ? i : u, e.notifyWith)), n[1][3].add(o(0, e, le(t) ? t : u)), n[2][3].add(o(0, e, le(r) ? r : l));
								})
								.promise();
						},
						promise: function (e) {
							return null != e ? he.extend(e, i) : i;
						},
					},
					o = {};
				return (
					he.each(n, function (e, t) {
						var s = t[2],
							a = t[5];
						(i[t[1]] = s.add),
							a &&
								s.add(
									function () {
										r = a;
									},
									n[3 - e][2].disable,
									n[3 - e][3].disable,
									n[0][2].lock,
									n[0][3].lock
								),
							s.add(t[3].fire),
							(o[t[0]] = function () {
								return o[t[0] + "With"](this === o ? void 0 : this, arguments), this;
							}),
							(o[t[0] + "With"] = s.fireWith);
					}),
					i.promise(o),
					t && t.call(o, o),
					o
				);
			},
			when: function (e) {
				var t = arguments.length,
					n = t,
					r = Array(n),
					i = Z.call(arguments),
					o = he.Deferred(),
					s = function (e) {
						return function (n) {
							(r[e] = this), (i[e] = 1 < arguments.length ? Z.call(arguments) : n), --t || o.resolveWith(r, i);
						};
					};
				if (t <= 1 && (c(e, o.done(s(n)).resolve, o.reject, !t), "pending" === o.state() || le(i[n] && i[n].then))) return o.then();
				for (; n--; ) c(i[n], s(n), o.reject);
				return o.promise();
			},
		});
	var Se = /^(Eval|Internal|Range|Reference|Syntax|Type|URI)Error$/;
	(he.Deferred.exceptionHook = function (t, n) {
		e.console && e.console.warn && t && Se.test(t.name) && e.console.warn("jQuery.Deferred exception: " + t.message, t.stack, n);
	}),
		(he.readyException = function (t) {
			e.setTimeout(function () {
				throw t;
			});
		});
	var ke = he.Deferred();
	(he.fn.ready = function (e) {
		return (
			ke.then(e).catch(function (e) {
				he.readyException(e);
			}),
			this
		);
	}),
		he.extend({
			isReady: !1,
			readyWait: 1,
			ready: function (e) {
				(!0 === e ? --he.readyWait : he.isReady) || ((he.isReady = !0) !== e && 0 < --he.readyWait) || ke.resolveWith(fe, [he]);
			},
		}),
		(he.ready.then = ke.then),
		"complete" === fe.readyState || ("loading" !== fe.readyState && !fe.documentElement.doScroll) ? e.setTimeout(he.ready) : (fe.addEventListener("DOMContentLoaded", f), e.addEventListener("load", f));
	var Ae = function (e, t, n, i, o, s, a) {
			var u = 0,
				l = e.length,
				c = null == n;
			if ("object" === r(n)) for (u in ((o = !0), n)) Ae(e, t, u, n[u], !0, s, a);
			else if (
				void 0 !== i &&
				((o = !0),
				le(i) || (a = !0),
				c &&
					(a
						? (t.call(e, i), (t = null))
						: ((c = t),
						  (t = function (e, t, n) {
								return c.call(he(e), n);
						  }))),
				t)
			)
				for (; u < l; u++) t(e[u], n, a ? i : i.call(e[u], u, t(e[u], n)));
			return o ? e : c ? t.call(e) : l ? t(e[0], n) : s;
		},
		De = /^-ms-/,
		Ne = /-([a-z])/g,
		je = function (e) {
			return 1 === e.nodeType || 9 === e.nodeType || !+e.nodeType;
		};
	(h.uid = 1),
		(h.prototype = {
			cache: function (e) {
				var t = e[this.expando];
				return t || ((t = {}), je(e) && (e.nodeType ? (e[this.expando] = t) : Object.defineProperty(e, this.expando, { value: t, configurable: !0 }))), t;
			},
			set: function (e, t, n) {
				var r,
					i = this.cache(e);
				if ("string" == typeof t) i[d(t)] = n;
				else for (r in t) i[d(r)] = t[r];
				return i;
			},
			get: function (e, t) {
				return void 0 === t ? this.cache(e) : e[this.expando] && e[this.expando][d(t)];
			},
			access: function (e, t, n) {
				return void 0 === t || (t && "string" == typeof t && void 0 === n) ? this.get(e, t) : (this.set(e, t, n), void 0 !== n ? n : t);
			},
			remove: function (e, t) {
				var n,
					r = e[this.expando];
				if (void 0 !== r) {
					if (void 0 !== t) {
						n = (t = Array.isArray(t) ? t.map(d) : (t = d(t)) in r ? [t] : t.match(Ee) || []).length;
						for (; n--; ) delete r[t[n]];
					}
					(void 0 === t || he.isEmptyObject(r)) && (e.nodeType ? (e[this.expando] = void 0) : delete e[this.expando]);
				}
			},
			hasData: function (e) {
				var t = e[this.expando];
				return void 0 !== t && !he.isEmptyObject(t);
			},
		});
	var Le = new h(),
		qe = new h(),
		_e = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
		Oe = /[A-Z]/g;
	he.extend({
		hasData: function (e) {
			return qe.hasData(e) || Le.hasData(e);
		},
		data: function (e, t, n) {
			return qe.access(e, t, n);
		},
		removeData: function (e, t) {
			qe.remove(e, t);
		},
		_data: function (e, t, n) {
			return Le.access(e, t, n);
		},
		_removeData: function (e, t) {
			Le.remove(e, t);
		},
	}),
		he.fn.extend({
			data: function (e, t) {
				var n,
					r,
					i,
					o = this[0],
					s = o && o.attributes;
				if (void 0 === e) {
					if (this.length && ((i = qe.get(o)), 1 === o.nodeType && !Le.get(o, "hasDataAttrs"))) {
						for (n = s.length; n--; ) s[n] && 0 === (r = s[n].name).indexOf("data-") && ((r = d(r.slice(5))), g(o, r, i[r]));
						Le.set(o, "hasDataAttrs", !0);
					}
					return i;
				}
				return "object" == typeof e
					? this.each(function () {
							qe.set(this, e);
					  })
					: Ae(
							this,
							function (t) {
								var n;
								if (o && void 0 === t) return void 0 !== (n = qe.get(o, e)) ? n : void 0 !== (n = g(o, e)) ? n : void 0;
								this.each(function () {
									qe.set(this, e, t);
								});
							},
							null,
							t,
							1 < arguments.length,
							null,
							!0
					  );
			},
			removeData: function (e) {
				return this.each(function () {
					qe.remove(this, e);
				});
			},
		}),
		he.extend({
			queue: function (e, t, n) {
				var r;
				if (e) return (t = (t || "fx") + "queue"), (r = Le.get(e, t)), n && (!r || Array.isArray(n) ? (r = Le.access(e, t, he.makeArray(n))) : r.push(n)), r || [];
			},
			dequeue: function (e, t) {
				t = t || "fx";
				var n = he.queue(e, t),
					r = n.length,
					i = n.shift(),
					o = he._queueHooks(e, t);
				"inprogress" === i && ((i = n.shift()), r--),
					i &&
						("fx" === t && n.unshift("inprogress"),
						delete o.stop,
						i.call(
							e,
							function () {
								he.dequeue(e, t);
							},
							o
						)),
					!r && o && o.empty.fire();
			},
			_queueHooks: function (e, t) {
				var n = t + "queueHooks";
				return (
					Le.get(e, n) ||
					Le.access(e, n, {
						empty: he.Callbacks("once memory").add(function () {
							Le.remove(e, [t + "queue", n]);
						}),
					})
				);
			},
		}),
		he.fn.extend({
			queue: function (e, t) {
				var n = 2;
				return (
					"string" != typeof e && ((t = e), (e = "fx"), n--),
					arguments.length < n
						? he.queue(this[0], e)
						: void 0 === t
						? this
						: this.each(function () {
								var n = he.queue(this, e, t);
								he._queueHooks(this, e), "fx" === e && "inprogress" !== n[0] && he.dequeue(this, e);
						  })
				);
			},
			dequeue: function (e) {
				return this.each(function () {
					he.dequeue(this, e);
				});
			},
			clearQueue: function (e) {
				return this.queue(e || "fx", []);
			},
			promise: function (e, t) {
				var n,
					r = 1,
					i = he.Deferred(),
					o = this,
					s = this.length,
					a = function () {
						--r || i.resolveWith(o, [o]);
					};
				for ("string" != typeof e && ((t = e), (e = void 0)), e = e || "fx"; s--; ) (n = Le.get(o[s], e + "queueHooks")) && n.empty && (r++, n.empty.add(a));
				return a(), i.promise(t);
			},
		});
	var Re = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
		Ie = new RegExp("^(?:([+-])=|)(" + Re + ")([a-z%]*)$", "i"),
		He = ["Top", "Right", "Bottom", "Left"],
		Me = fe.documentElement,
		Pe = function (e) {
			return he.contains(e.ownerDocument, e);
		},
		Fe = { composed: !0 };
	Me.getRootNode &&
		(Pe = function (e) {
			return he.contains(e.ownerDocument, e) || e.getRootNode(Fe) === e.ownerDocument;
		});
	var We = function (e, t) {
			return "none" === (e = t || e).style.display || ("" === e.style.display && Pe(e) && "none" === he.css(e, "display"));
		},
		Be = {};
	he.fn.extend({
		show: function () {
			return m(this, !0);
		},
		hide: function () {
			return m(this);
		},
		toggle: function (e) {
			return "boolean" == typeof e
				? e
					? this.show()
					: this.hide()
				: this.each(function () {
						We(this) ? he(this).show() : he(this).hide();
				  });
		},
	});
	var $e,
		Ue,
		ze = /^(?:checkbox|radio)$/i,
		Ve = /<([a-z][^\/\0>\x20\t\r\n\f]*)/i,
		Xe = /^$|^module$|\/(?:java|ecma)script/i;
	($e = fe.createDocumentFragment().appendChild(fe.createElement("div"))),
		(Ue = fe.createElement("input")).setAttribute("type", "radio"),
		Ue.setAttribute("checked", "checked"),
		Ue.setAttribute("name", "t"),
		$e.appendChild(Ue),
		(ue.checkClone = $e.cloneNode(!0).cloneNode(!0).lastChild.checked),
		($e.innerHTML = "<textarea>x</textarea>"),
		(ue.noCloneChecked = !!$e.cloneNode(!0).lastChild.defaultValue),
		($e.innerHTML = "<option></option>"),
		(ue.option = !!$e.lastChild);
	var Ge = { thead: [1, "<table>", "</table>"], col: [2, "<table><colgroup>", "</colgroup></table>"], tr: [2, "<table><tbody>", "</tbody></table>"], td: [3, "<table><tbody><tr>", "</tr></tbody></table>"], _default: [0, "", ""] };
	(Ge.tbody = Ge.tfoot = Ge.colgroup = Ge.caption = Ge.thead), (Ge.th = Ge.td), ue.option || (Ge.optgroup = Ge.option = [1, "<select multiple='multiple'>", "</select>"]);
	var Ye = /<|&#?\w+;/,
		Qe = /^key/,
		Je = /^(?:mouse|pointer|contextmenu|drag|drop)|click/,
		Ke = /^([^.]*)(?:\.(.+)|)/;
	(he.event = {
		global: {},
		add: function (e, t, n, r, i) {
			var o,
				s,
				a,
				u,
				l,
				c,
				f,
				p,
				d,
				h,
				g,
				v = Le.get(e);
			if (je(e))
				for (
					n.handler && ((n = (o = n).handler), (i = o.selector)),
						i && he.find.matchesSelector(Me, i),
						n.guid || (n.guid = he.guid++),
						(u = v.events) || (u = v.events = Object.create(null)),
						(s = v.handle) ||
							(s = v.handle = function (t) {
								return void 0 !== he && he.event.triggered !== t.type ? he.event.dispatch.apply(e, arguments) : void 0;
							}),
						l = (t = (t || "").match(Ee) || [""]).length;
					l--;

				)
					(d = g = (a = Ke.exec(t[l]) || [])[1]),
						(h = (a[2] || "").split(".").sort()),
						d &&
							((f = he.event.special[d] || {}),
							(d = (i ? f.delegateType : f.bindType) || d),
							(f = he.event.special[d] || {}),
							(c = he.extend({ type: d, origType: g, data: r, handler: n, guid: n.guid, selector: i, needsContext: i && he.expr.match.needsContext.test(i), namespace: h.join(".") }, o)),
							(p = u[d]) || (((p = u[d] = []).delegateCount = 0), (f.setup && !1 !== f.setup.call(e, r, h, s)) || (e.addEventListener && e.addEventListener(d, s))),
							f.add && (f.add.call(e, c), c.handler.guid || (c.handler.guid = n.guid)),
							i ? p.splice(p.delegateCount++, 0, c) : p.push(c),
							(he.event.global[d] = !0));
		},
		remove: function (e, t, n, r, i) {
			var o,
				s,
				a,
				u,
				l,
				c,
				f,
				p,
				d,
				h,
				g,
				v = Le.hasData(e) && Le.get(e);
			if (v && (u = v.events)) {
				for (l = (t = (t || "").match(Ee) || [""]).length; l--; )
					if (((d = g = (a = Ke.exec(t[l]) || [])[1]), (h = (a[2] || "").split(".").sort()), d)) {
						for (f = he.event.special[d] || {}, p = u[(d = (r ? f.delegateType : f.bindType) || d)] || [], a = a[2] && new RegExp("(^|\\.)" + h.join("\\.(?:.*\\.|)") + "(\\.|$)"), s = o = p.length; o--; )
							(c = p[o]),
								(!i && g !== c.origType) || (n && n.guid !== c.guid) || (a && !a.test(c.namespace)) || (r && r !== c.selector && ("**" !== r || !c.selector)) || (p.splice(o, 1), c.selector && p.delegateCount--, f.remove && f.remove.call(e, c));
						s && !p.length && ((f.teardown && !1 !== f.teardown.call(e, h, v.handle)) || he.removeEvent(e, d, v.handle), delete u[d]);
					} else for (d in u) he.event.remove(e, d + t[l], n, r, !0);
				he.isEmptyObject(u) && Le.remove(e, "handle events");
			}
		},
		dispatch: function (e) {
			var t,
				n,
				r,
				i,
				o,
				s,
				a = new Array(arguments.length),
				u = he.event.fix(e),
				l = (Le.get(this, "events") || Object.create(null))[u.type] || [],
				c = he.event.special[u.type] || {};
			for (a[0] = u, t = 1; t < arguments.length; t++) a[t] = arguments[t];
			if (((u.delegateTarget = this), !c.preDispatch || !1 !== c.preDispatch.call(this, u))) {
				for (s = he.event.handlers.call(this, u, l), t = 0; (i = s[t++]) && !u.isPropagationStopped(); )
					for (u.currentTarget = i.elem, n = 0; (o = i.handlers[n++]) && !u.isImmediatePropagationStopped(); )
						(u.rnamespace && !1 !== o.namespace && !u.rnamespace.test(o.namespace)) ||
							((u.handleObj = o), (u.data = o.data), void 0 !== (r = ((he.event.special[o.origType] || {}).handle || o.handler).apply(i.elem, a)) && !1 === (u.result = r) && (u.preventDefault(), u.stopPropagation()));
				return c.postDispatch && c.postDispatch.call(this, u), u.result;
			}
		},
		handlers: function (e, t) {
			var n,
				r,
				i,
				o,
				s,
				a = [],
				u = t.delegateCount,
				l = e.target;
			if (u && l.nodeType && !("click" === e.type && 1 <= e.button))
				for (; l !== this; l = l.parentNode || this)
					if (1 === l.nodeType && ("click" !== e.type || !0 !== l.disabled)) {
						for (o = [], s = {}, n = 0; n < u; n++) void 0 === s[(i = (r = t[n]).selector + " ")] && (s[i] = r.needsContext ? -1 < he(i, this).index(l) : he.find(i, this, null, [l]).length), s[i] && o.push(r);
						o.length && a.push({ elem: l, handlers: o });
					}
			return (l = this), u < t.length && a.push({ elem: l, handlers: t.slice(u) }), a;
		},
		addProp: function (e, t) {
			Object.defineProperty(he.Event.prototype, e, {
				enumerable: !0,
				configurable: !0,
				get: le(t)
					? function () {
							if (this.originalEvent) return t(this.originalEvent);
					  }
					: function () {
							if (this.originalEvent) return this.originalEvent[e];
					  },
				set: function (t) {
					Object.defineProperty(this, e, { enumerable: !0, configurable: !0, writable: !0, value: t });
				},
			});
		},
		fix: function (e) {
			return e[he.expando] ? e : new he.Event(e);
		},
		special: {
			load: { noBubble: !0 },
			click: {
				setup: function (e) {
					var t = this || e;
					return ze.test(t.type) && t.click && o(t, "input") && S(t, "click", w), !1;
				},
				trigger: function (e) {
					var t = this || e;
					return ze.test(t.type) && t.click && o(t, "input") && S(t, "click"), !0;
				},
				_default: function (e) {
					var t = e.target;
					return (ze.test(t.type) && t.click && o(t, "input") && Le.get(t, "click")) || o(t, "a");
				},
			},
			beforeunload: {
				postDispatch: function (e) {
					void 0 !== e.result && e.originalEvent && (e.originalEvent.returnValue = e.result);
				},
			},
		},
	}),
		(he.removeEvent = function (e, t, n) {
			e.removeEventListener && e.removeEventListener(t, n);
		}),
		(he.Event = function (e, t) {
			if (!(this instanceof he.Event)) return new he.Event(e, t);
			e && e.type
				? ((this.originalEvent = e),
				  (this.type = e.type),
				  (this.isDefaultPrevented = e.defaultPrevented || (void 0 === e.defaultPrevented && !1 === e.returnValue) ? w : T),
				  (this.target = e.target && 3 === e.target.nodeType ? e.target.parentNode : e.target),
				  (this.currentTarget = e.currentTarget),
				  (this.relatedTarget = e.relatedTarget))
				: (this.type = e),
				t && he.extend(this, t),
				(this.timeStamp = (e && e.timeStamp) || Date.now()),
				(this[he.expando] = !0);
		}),
		(he.Event.prototype = {
			constructor: he.Event,
			isDefaultPrevented: T,
			isPropagationStopped: T,
			isImmediatePropagationStopped: T,
			isSimulated: !1,
			preventDefault: function () {
				var e = this.originalEvent;
				(this.isDefaultPrevented = w), e && !this.isSimulated && e.preventDefault();
			},
			stopPropagation: function () {
				var e = this.originalEvent;
				(this.isPropagationStopped = w), e && !this.isSimulated && e.stopPropagation();
			},
			stopImmediatePropagation: function () {
				var e = this.originalEvent;
				(this.isImmediatePropagationStopped = w), e && !this.isSimulated && e.stopImmediatePropagation(), this.stopPropagation();
			},
		}),
		he.each(
			{
				altKey: !0,
				bubbles: !0,
				cancelable: !0,
				changedTouches: !0,
				ctrlKey: !0,
				detail: !0,
				eventPhase: !0,
				metaKey: !0,
				pageX: !0,
				pageY: !0,
				shiftKey: !0,
				view: !0,
				char: !0,
				code: !0,
				charCode: !0,
				key: !0,
				keyCode: !0,
				button: !0,
				buttons: !0,
				clientX: !0,
				clientY: !0,
				offsetX: !0,
				offsetY: !0,
				pointerId: !0,
				pointerType: !0,
				screenX: !0,
				screenY: !0,
				targetTouches: !0,
				toElement: !0,
				touches: !0,
				which: function (e) {
					var t = e.button;
					return null == e.which && Qe.test(e.type) ? (null != e.charCode ? e.charCode : e.keyCode) : !e.which && void 0 !== t && Je.test(e.type) ? (1 & t ? 1 : 2 & t ? 3 : 4 & t ? 2 : 0) : e.which;
				},
			},
			he.event.addProp
		),
		he.each({ focus: "focusin", blur: "focusout" }, function (e, t) {
			he.event.special[e] = {
				setup: function () {
					return S(this, e, C), !1;
				},
				trigger: function () {
					return S(this, e), !0;
				},
				delegateType: t,
			};
		}),
		he.each({ mouseenter: "mouseover", mouseleave: "mouseout", pointerenter: "pointerover", pointerleave: "pointerout" }, function (e, t) {
			he.event.special[e] = {
				delegateType: t,
				bindType: t,
				handle: function (e) {
					var n,
						r = e.relatedTarget,
						i = e.handleObj;
					return (r && (r === this || he.contains(this, r))) || ((e.type = i.origType), (n = i.handler.apply(this, arguments)), (e.type = t)), n;
				},
			};
		}),
		he.fn.extend({
			on: function (e, t, n, r) {
				return E(this, e, t, n, r);
			},
			one: function (e, t, n, r) {
				return E(this, e, t, n, r, 1);
			},
			off: function (e, t, n) {
				var r, i;
				if (e && e.preventDefault && e.handleObj) return (r = e.handleObj), he(e.delegateTarget).off(r.namespace ? r.origType + "." + r.namespace : r.origType, r.selector, r.handler), this;
				if ("object" == typeof e) {
					for (i in e) this.off(i, t, e[i]);
					return this;
				}
				return (
					(!1 !== t && "function" != typeof t) || ((n = t), (t = void 0)),
					!1 === n && (n = T),
					this.each(function () {
						he.event.remove(this, e, n, t);
					})
				);
			},
		});
	var Ze = /<script|<style|<link/i,
		et = /checked\s*(?:[^=]|=\s*.checked.)/i,
		tt = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g;
	he.extend({
		htmlPrefilter: function (e) {
			return e;
		},
		clone: function (e, t, n) {
			var r,
				i,
				o,
				s,
				a,
				u,
				l,
				c = e.cloneNode(!0),
				f = Pe(e);
			if (!(ue.noCloneChecked || (1 !== e.nodeType && 11 !== e.nodeType) || he.isXMLDoc(e)))
				for (s = y(c), r = 0, i = (o = y(e)).length; r < i; r++)
					(a = o[r]), (u = s[r]), "input" === (l = u.nodeName.toLowerCase()) && ze.test(a.type) ? (u.checked = a.checked) : ("input" !== l && "textarea" !== l) || (u.defaultValue = a.defaultValue);
			if (t)
				if (n) for (o = o || y(e), s = s || y(c), r = 0, i = o.length; r < i; r++) N(o[r], s[r]);
				else N(e, c);
			return 0 < (s = y(c, "script")).length && b(s, !f && y(e, "script")), c;
		},
		cleanData: function (e) {
			for (var t, n, r, i = he.event.special, o = 0; void 0 !== (n = e[o]); o++)
				if (je(n)) {
					if ((t = n[Le.expando])) {
						if (t.events) for (r in t.events) i[r] ? he.event.remove(n, r) : he.removeEvent(n, r, t.handle);
						n[Le.expando] = void 0;
					}
					n[qe.expando] && (n[qe.expando] = void 0);
				}
		},
	}),
		he.fn.extend({
			detach: function (e) {
				return L(this, e, !0);
			},
			remove: function (e) {
				return L(this, e);
			},
			text: function (e) {
				return Ae(
					this,
					function (e) {
						return void 0 === e
							? he.text(this)
							: this.empty().each(function () {
									(1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType) || (this.textContent = e);
							  });
					},
					null,
					e,
					arguments.length
				);
			},
			append: function () {
				return j(this, arguments, function (e) {
					(1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType) || k(this, e).appendChild(e);
				});
			},
			prepend: function () {
				return j(this, arguments, function (e) {
					if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
						var t = k(this, e);
						t.insertBefore(e, t.firstChild);
					}
				});
			},
			before: function () {
				return j(this, arguments, function (e) {
					this.parentNode && this.parentNode.insertBefore(e, this);
				});
			},
			after: function () {
				return j(this, arguments, function (e) {
					this.parentNode && this.parentNode.insertBefore(e, this.nextSibling);
				});
			},
			empty: function () {
				for (var e, t = 0; null != (e = this[t]); t++) 1 === e.nodeType && (he.cleanData(y(e, !1)), (e.textContent = ""));
				return this;
			},
			clone: function (e, t) {
				return (
					(e = null != e && e),
					(t = null == t ? e : t),
					this.map(function () {
						return he.clone(this, e, t);
					})
				);
			},
			html: function (e) {
				return Ae(
					this,
					function (e) {
						var t = this[0] || {},
							n = 0,
							r = this.length;
						if (void 0 === e && 1 === t.nodeType) return t.innerHTML;
						if ("string" == typeof e && !Ze.test(e) && !Ge[(Ve.exec(e) || ["", ""])[1].toLowerCase()]) {
							e = he.htmlPrefilter(e);
							try {
								for (; n < r; n++) 1 === (t = this[n] || {}).nodeType && (he.cleanData(y(t, !1)), (t.innerHTML = e));
								t = 0;
							} catch (e) {}
						}
						t && this.empty().append(e);
					},
					null,
					e,
					arguments.length
				);
			},
			replaceWith: function () {
				var e = [];
				return j(
					this,
					arguments,
					function (t) {
						var n = this.parentNode;
						he.inArray(this, e) < 0 && (he.cleanData(y(this)), n && n.replaceChild(t, this));
					},
					e
				);
			},
		}),
		he.each({ appendTo: "append", prependTo: "prepend", insertBefore: "before", insertAfter: "after", replaceAll: "replaceWith" }, function (e, t) {
			he.fn[e] = function (e) {
				for (var n, r = [], i = he(e), o = i.length - 1, s = 0; s <= o; s++) (n = s === o ? this : this.clone(!0)), he(i[s])[t](n), te.apply(r, n.get());
				return this.pushStack(r);
			};
		});
	var nt = new RegExp("^(" + Re + ")(?!px)[a-z%]+$", "i"),
		rt = function (t) {
			var n = t.ownerDocument.defaultView;
			return (n && n.opener) || (n = e), n.getComputedStyle(t);
		},
		it = function (e, t, n) {
			var r,
				i,
				o = {};
			for (i in t) (o[i] = e.style[i]), (e.style[i] = t[i]);
			for (i in ((r = n.call(e)), t)) e.style[i] = o[i];
			return r;
		},
		ot = new RegExp(He.join("|"), "i");
	!(function () {
		function t() {
			if (c) {
				(l.style.cssText = "position:absolute;left:-11111px;width:60px;margin-top:1px;padding:0;border:0"),
					(c.style.cssText = "position:relative;display:block;box-sizing:border-box;overflow:scroll;margin:auto;border:1px;padding:1px;width:60%;top:1%"),
					Me.appendChild(l).appendChild(c);
				var t = e.getComputedStyle(c);
				(r = "1%" !== t.top), (u = 12 === n(t.marginLeft)), (c.style.right = "60%"), (s = 36 === n(t.right)), (i = 36 === n(t.width)), (c.style.position = "absolute"), (o = 12 === n(c.offsetWidth / 3)), Me.removeChild(l), (c = null);
			}
		}
		function n(e) {
			return Math.round(parseFloat(e));
		}
		var r,
			i,
			o,
			s,
			a,
			u,
			l = fe.createElement("div"),
			c = fe.createElement("div");
		c.style &&
			((c.style.backgroundClip = "content-box"),
			(c.cloneNode(!0).style.backgroundClip = ""),
			(ue.clearCloneStyle = "content-box" === c.style.backgroundClip),
			he.extend(ue, {
				boxSizingReliable: function () {
					return t(), i;
				},
				pixelBoxStyles: function () {
					return t(), s;
				},
				pixelPosition: function () {
					return t(), r;
				},
				reliableMarginLeft: function () {
					return t(), u;
				},
				scrollboxSize: function () {
					return t(), o;
				},
				reliableTrDimensions: function () {
					var t, n, r, i;
					return (
						null == a &&
							((t = fe.createElement("table")),
							(n = fe.createElement("tr")),
							(r = fe.createElement("div")),
							(t.style.cssText = "position:absolute;left:-11111px"),
							(n.style.height = "1px"),
							(r.style.height = "9px"),
							Me.appendChild(t).appendChild(n).appendChild(r),
							(i = e.getComputedStyle(n)),
							(a = 3 < parseInt(i.height)),
							Me.removeChild(t)),
						a
					);
				},
			}));
	})();
	var st = ["Webkit", "Moz", "ms"],
		at = fe.createElement("div").style,
		ut = {},
		lt = /^(none|table(?!-c[ea]).+)/,
		ct = /^--/,
		ft = { position: "absolute", visibility: "hidden", display: "block" },
		pt = { letterSpacing: "0", fontWeight: "400" };
	he.extend({
		cssHooks: {
			opacity: {
				get: function (e, t) {
					if (t) {
						var n = q(e, "opacity");
						return "" === n ? "1" : n;
					}
				},
			},
		},
		cssNumber: {
			animationIterationCount: !0,
			columnCount: !0,
			fillOpacity: !0,
			flexGrow: !0,
			flexShrink: !0,
			fontWeight: !0,
			gridArea: !0,
			gridColumn: !0,
			gridColumnEnd: !0,
			gridColumnStart: !0,
			gridRow: !0,
			gridRowEnd: !0,
			gridRowStart: !0,
			lineHeight: !0,
			opacity: !0,
			order: !0,
			orphans: !0,
			widows: !0,
			zIndex: !0,
			zoom: !0,
		},
		cssProps: {},
		style: function (e, t, n, r) {
			if (e && 3 !== e.nodeType && 8 !== e.nodeType && e.style) {
				var i,
					o,
					s,
					a = d(t),
					u = ct.test(t),
					l = e.style;
				if ((u || (t = O(a)), (s = he.cssHooks[t] || he.cssHooks[a]), void 0 === n)) return s && "get" in s && void 0 !== (i = s.get(e, !1, r)) ? i : l[t];
				"string" == (o = typeof n) && (i = Ie.exec(n)) && i[1] && ((n = v(e, t, i)), (o = "number")),
					null != n &&
						n == n &&
						("number" !== o || u || (n += (i && i[3]) || (he.cssNumber[a] ? "" : "px")),
						ue.clearCloneStyle || "" !== n || 0 !== t.indexOf("background") || (l[t] = "inherit"),
						(s && "set" in s && void 0 === (n = s.set(e, n, r))) || (u ? l.setProperty(t, n) : (l[t] = n)));
			}
		},
		css: function (e, t, n, r) {
			var i,
				o,
				s,
				a = d(t);
			return (
				ct.test(t) || (t = O(a)),
				(s = he.cssHooks[t] || he.cssHooks[a]) && "get" in s && (i = s.get(e, !0, n)),
				void 0 === i && (i = q(e, t, r)),
				"normal" === i && t in pt && (i = pt[t]),
				"" === n || n ? ((o = parseFloat(i)), !0 === n || isFinite(o) ? o || 0 : i) : i
			);
		},
	}),
		he.each(["height", "width"], function (e, t) {
			he.cssHooks[t] = {
				get: function (e, n, r) {
					if (n)
						return !lt.test(he.css(e, "display")) || (e.getClientRects().length && e.getBoundingClientRect().width)
							? H(e, t, r)
							: it(e, ft, function () {
									return H(e, t, r);
							  });
				},
				set: function (e, n, r) {
					var i,
						o = rt(e),
						s = !ue.scrollboxSize() && "absolute" === o.position,
						a = (s || r) && "border-box" === he.css(e, "boxSizing", !1, o),
						u = r ? I(e, t, r, a, o) : 0;
					return a && s && (u -= Math.ceil(e["offset" + t[0].toUpperCase() + t.slice(1)] - parseFloat(o[t]) - I(e, t, "border", !1, o) - 0.5)), u && (i = Ie.exec(n)) && "px" !== (i[3] || "px") && ((e.style[t] = n), (n = he.css(e, t))), R(0, n, u);
				},
			};
		}),
		(he.cssHooks.marginLeft = _(ue.reliableMarginLeft, function (e, t) {
			if (t)
				return (
					(parseFloat(q(e, "marginLeft")) ||
						e.getBoundingClientRect().left -
							it(e, { marginLeft: 0 }, function () {
								return e.getBoundingClientRect().left;
							})) + "px"
				);
		})),
		he.each({ margin: "", padding: "", border: "Width" }, function (e, t) {
			(he.cssHooks[e + t] = {
				expand: function (n) {
					for (var r = 0, i = {}, o = "string" == typeof n ? n.split(" ") : [n]; r < 4; r++) i[e + He[r] + t] = o[r] || o[r - 2] || o[0];
					return i;
				},
			}),
				"margin" !== e && (he.cssHooks[e + t].set = R);
		}),
		he.fn.extend({
			css: function (e, t) {
				return Ae(
					this,
					function (e, t, n) {
						var r,
							i,
							o = {},
							s = 0;
						if (Array.isArray(t)) {
							for (r = rt(e), i = t.length; s < i; s++) o[t[s]] = he.css(e, t[s], !1, r);
							return o;
						}
						return void 0 !== n ? he.style(e, t, n) : he.css(e, t);
					},
					e,
					t,
					1 < arguments.length
				);
			},
		}),
		(((he.Tween = M).prototype = {
			constructor: M,
			init: function (e, t, n, r, i, o) {
				(this.elem = e), (this.prop = n), (this.easing = i || he.easing._default), (this.options = t), (this.start = this.now = this.cur()), (this.end = r), (this.unit = o || (he.cssNumber[n] ? "" : "px"));
			},
			cur: function () {
				var e = M.propHooks[this.prop];
				return e && e.get ? e.get(this) : M.propHooks._default.get(this);
			},
			run: function (e) {
				var t,
					n = M.propHooks[this.prop];
				return (
					this.options.duration ? (this.pos = t = he.easing[this.easing](e, this.options.duration * e, 0, 1, this.options.duration)) : (this.pos = t = e),
					(this.now = (this.end - this.start) * t + this.start),
					this.options.step && this.options.step.call(this.elem, this.now, this),
					n && n.set ? n.set(this) : M.propHooks._default.set(this),
					this
				);
			},
		}).init.prototype = M.prototype),
		((M.propHooks = {
			_default: {
				get: function (e) {
					var t;
					return 1 !== e.elem.nodeType || (null != e.elem[e.prop] && null == e.elem.style[e.prop]) ? e.elem[e.prop] : (t = he.css(e.elem, e.prop, "")) && "auto" !== t ? t : 0;
				},
				set: function (e) {
					he.fx.step[e.prop] ? he.fx.step[e.prop](e) : 1 !== e.elem.nodeType || (!he.cssHooks[e.prop] && null == e.elem.style[O(e.prop)]) ? (e.elem[e.prop] = e.now) : he.style(e.elem, e.prop, e.now + e.unit);
				},
			},
		}).scrollTop = M.propHooks.scrollLeft = {
			set: function (e) {
				e.elem.nodeType && e.elem.parentNode && (e.elem[e.prop] = e.now);
			},
		}),
		(he.easing = {
			linear: function (e) {
				return e;
			},
			swing: function (e) {
				return 0.5 - Math.cos(e * Math.PI) / 2;
			},
			_default: "swing",
		}),
		(he.fx = M.prototype.init),
		(he.fx.step = {});
	var dt,
		ht,
		gt,
		vt,
		mt = /^(?:toggle|show|hide)$/,
		yt = /queueHooks$/;
	(he.Animation = he.extend($, {
		tweeners: {
			"*": [
				function (e, t) {
					var n = this.createTween(e, t);
					return v(n.elem, e, Ie.exec(t), n), n;
				},
			],
		},
		tweener: function (e, t) {
			le(e) ? ((t = e), (e = ["*"])) : (e = e.match(Ee));
			for (var n, r = 0, i = e.length; r < i; r++) (n = e[r]), ($.tweeners[n] = $.tweeners[n] || []), $.tweeners[n].unshift(t);
		},
		prefilters: [
			function (e, t, n) {
				var r,
					i,
					o,
					s,
					a,
					u,
					l,
					c,
					f = "width" in t || "height" in t,
					p = this,
					d = {},
					h = e.style,
					g = e.nodeType && We(e),
					v = Le.get(e, "fxshow");
				for (r in (n.queue ||
					(null == (s = he._queueHooks(e, "fx")).unqueued &&
						((s.unqueued = 0),
						(a = s.empty.fire),
						(s.empty.fire = function () {
							s.unqueued || a();
						})),
					s.unqueued++,
					p.always(function () {
						p.always(function () {
							s.unqueued--, he.queue(e, "fx").length || s.empty.fire();
						});
					})),
				t))
					if (((i = t[r]), mt.test(i))) {
						if ((delete t[r], (o = o || "toggle" === i), i === (g ? "hide" : "show"))) {
							if ("show" !== i || !v || void 0 === v[r]) continue;
							g = !0;
						}
						d[r] = (v && v[r]) || he.style(e, r);
					}
				if ((u = !he.isEmptyObject(t)) || !he.isEmptyObject(d))
					for (r in (f &&
						1 === e.nodeType &&
						((n.overflow = [h.overflow, h.overflowX, h.overflowY]),
						null == (l = v && v.display) && (l = Le.get(e, "display")),
						"none" === (c = he.css(e, "display")) && (l ? (c = l) : (m([e], !0), (l = e.style.display || l), (c = he.css(e, "display")), m([e]))),
						("inline" === c || ("inline-block" === c && null != l)) &&
							"none" === he.css(e, "float") &&
							(u ||
								(p.done(function () {
									h.display = l;
								}),
								null == l && ((c = h.display), (l = "none" === c ? "" : c))),
							(h.display = "inline-block"))),
					n.overflow &&
						((h.overflow = "hidden"),
						p.always(function () {
							(h.overflow = n.overflow[0]), (h.overflowX = n.overflow[1]), (h.overflowY = n.overflow[2]);
						})),
					(u = !1),
					d))
						u ||
							(v ? "hidden" in v && (g = v.hidden) : (v = Le.access(e, "fxshow", { display: l })),
							o && (v.hidden = !g),
							g && m([e], !0),
							p.done(function () {
								for (r in (g || m([e]), Le.remove(e, "fxshow"), d)) he.style(e, r, d[r]);
							})),
							(u = B(g ? v[r] : 0, r, p)),
							r in v || ((v[r] = u.start), g && ((u.end = u.start), (u.start = 0)));
			},
		],
		prefilter: function (e, t) {
			t ? $.prefilters.unshift(e) : $.prefilters.push(e);
		},
	})),
		(he.speed = function (e, t, n) {
			var r = e && "object" == typeof e ? he.extend({}, e) : { complete: n || (!n && t) || (le(e) && e), duration: e, easing: (n && t) || (t && !le(t) && t) };
			return (
				he.fx.off ? (r.duration = 0) : "number" != typeof r.duration && (r.duration in he.fx.speeds ? (r.duration = he.fx.speeds[r.duration]) : (r.duration = he.fx.speeds._default)),
				(null != r.queue && !0 !== r.queue) || (r.queue = "fx"),
				(r.old = r.complete),
				(r.complete = function () {
					le(r.old) && r.old.call(this), r.queue && he.dequeue(this, r.queue);
				}),
				r
			);
		}),
		he.fn.extend({
			fadeTo: function (e, t, n, r) {
				return this.filter(We).css("opacity", 0).show().end().animate({ opacity: t }, e, n, r);
			},
			animate: function (e, t, n, r) {
				var i = he.isEmptyObject(e),
					o = he.speed(t, n, r),
					s = function () {
						var t = $(this, he.extend({}, e), o);
						(i || Le.get(this, "finish")) && t.stop(!0);
					};
				return (s.finish = s), i || !1 === o.queue ? this.each(s) : this.queue(o.queue, s);
			},
			stop: function (e, t, n) {
				var r = function (e) {
					var t = e.stop;
					delete e.stop, t(n);
				};
				return (
					"string" != typeof e && ((n = t), (t = e), (e = void 0)),
					t && this.queue(e || "fx", []),
					this.each(function () {
						var t = !0,
							i = null != e && e + "queueHooks",
							o = he.timers,
							s = Le.get(this);
						if (i) s[i] && s[i].stop && r(s[i]);
						else for (i in s) s[i] && s[i].stop && yt.test(i) && r(s[i]);
						for (i = o.length; i--; ) o[i].elem !== this || (null != e && o[i].queue !== e) || (o[i].anim.stop(n), (t = !1), o.splice(i, 1));
						(!t && n) || he.dequeue(this, e);
					})
				);
			},
			finish: function (e) {
				return (
					!1 !== e && (e = e || "fx"),
					this.each(function () {
						var t,
							n = Le.get(this),
							r = n[e + "queue"],
							i = n[e + "queueHooks"],
							o = he.timers,
							s = r ? r.length : 0;
						for (n.finish = !0, he.queue(this, e, []), i && i.stop && i.stop.call(this, !0), t = o.length; t--; ) o[t].elem === this && o[t].queue === e && (o[t].anim.stop(!0), o.splice(t, 1));
						for (t = 0; t < s; t++) r[t] && r[t].finish && r[t].finish.call(this);
						delete n.finish;
					})
				);
			},
		}),
		he.each(["toggle", "show", "hide"], function (e, t) {
			var n = he.fn[t];
			he.fn[t] = function (e, r, i) {
				return null == e || "boolean" == typeof e ? n.apply(this, arguments) : this.animate(W(t, !0), e, r, i);
			};
		}),
		he.each({ slideDown: W("show"), slideUp: W("hide"), slideToggle: W("toggle"), fadeIn: { opacity: "show" }, fadeOut: { opacity: "hide" }, fadeToggle: { opacity: "toggle" } }, function (e, t) {
			he.fn[e] = function (e, n, r) {
				return this.animate(t, e, n, r);
			};
		}),
		(he.timers = []),
		(he.fx.tick = function () {
			var e,
				t = 0,
				n = he.timers;
			for (dt = Date.now(); t < n.length; t++) (e = n[t])() || n[t] !== e || n.splice(t--, 1);
			n.length || he.fx.stop(), (dt = void 0);
		}),
		(he.fx.timer = function (e) {
			he.timers.push(e), he.fx.start();
		}),
		(he.fx.interval = 13),
		(he.fx.start = function () {
			ht || ((ht = !0), P());
		}),
		(he.fx.stop = function () {
			ht = null;
		}),
		(he.fx.speeds = { slow: 600, fast: 200, _default: 400 }),
		(he.fn.delay = function (t, n) {
			return (
				(t = (he.fx && he.fx.speeds[t]) || t),
				(n = n || "fx"),
				this.queue(n, function (n, r) {
					var i = e.setTimeout(n, t);
					r.stop = function () {
						e.clearTimeout(i);
					};
				})
			);
		}),
		(gt = fe.createElement("input")),
		(vt = fe.createElement("select").appendChild(fe.createElement("option"))),
		(gt.type = "checkbox"),
		(ue.checkOn = "" !== gt.value),
		(ue.optSelected = vt.selected),
		((gt = fe.createElement("input")).value = "t"),
		(gt.type = "radio"),
		(ue.radioValue = "t" === gt.value);
	var bt,
		xt = he.expr.attrHandle;
	he.fn.extend({
		attr: function (e, t) {
			return Ae(this, he.attr, e, t, 1 < arguments.length);
		},
		removeAttr: function (e) {
			return this.each(function () {
				he.removeAttr(this, e);
			});
		},
	}),
		he.extend({
			attr: function (e, t, n) {
				var r,
					i,
					o = e.nodeType;
				if (3 !== o && 8 !== o && 2 !== o)
					return void 0 === e.getAttribute
						? he.prop(e, t, n)
						: ((1 === o && he.isXMLDoc(e)) || (i = he.attrHooks[t.toLowerCase()] || (he.expr.match.bool.test(t) ? bt : void 0)),
						  void 0 !== n
								? null === n
									? void he.removeAttr(e, t)
									: i && "set" in i && void 0 !== (r = i.set(e, n, t))
									? r
									: (e.setAttribute(t, n + ""), n)
								: i && "get" in i && null !== (r = i.get(e, t))
								? r
								: null == (r = he.find.attr(e, t))
								? void 0
								: r);
			},
			attrHooks: {
				type: {
					set: function (e, t) {
						if (!ue.radioValue && "radio" === t && o(e, "input")) {
							var n = e.value;
							return e.setAttribute("type", t), n && (e.value = n), t;
						}
					},
				},
			},
			removeAttr: function (e, t) {
				var n,
					r = 0,
					i = t && t.match(Ee);
				if (i && 1 === e.nodeType) for (; (n = i[r++]); ) e.removeAttribute(n);
			},
		}),
		(bt = {
			set: function (e, t, n) {
				return !1 === t ? he.removeAttr(e, n) : e.setAttribute(n, n), n;
			},
		}),
		he.each(he.expr.match.bool.source.match(/\w+/g), function (e, t) {
			var n = xt[t] || he.find.attr;
			xt[t] = function (e, t, r) {
				var i,
					o,
					s = t.toLowerCase();
				return r || ((o = xt[s]), (xt[s] = i), (i = null != n(e, t, r) ? s : null), (xt[s] = o)), i;
			};
		});
	var wt = /^(?:input|select|textarea|button)$/i,
		Tt = /^(?:a|area)$/i;
	he.fn.extend({
		prop: function (e, t) {
			return Ae(this, he.prop, e, t, 1 < arguments.length);
		},
		removeProp: function (e) {
			return this.each(function () {
				delete this[he.propFix[e] || e];
			});
		},
	}),
		he.extend({
			prop: function (e, t, n) {
				var r,
					i,
					o = e.nodeType;
				if (3 !== o && 8 !== o && 2 !== o)
					return (1 === o && he.isXMLDoc(e)) || ((t = he.propFix[t] || t), (i = he.propHooks[t])), void 0 !== n ? (i && "set" in i && void 0 !== (r = i.set(e, n, t)) ? r : (e[t] = n)) : i && "get" in i && null !== (r = i.get(e, t)) ? r : e[t];
			},
			propHooks: {
				tabIndex: {
					get: function (e) {
						var t = he.find.attr(e, "tabindex");
						return t ? parseInt(t, 10) : wt.test(e.nodeName) || (Tt.test(e.nodeName) && e.href) ? 0 : -1;
					},
				},
			},
			propFix: { for: "htmlFor", class: "className" },
		}),
		ue.optSelected ||
			(he.propHooks.selected = {
				get: function (e) {
					var t = e.parentNode;
					return t && t.parentNode && t.parentNode.selectedIndex, null;
				},
				set: function (e) {
					var t = e.parentNode;
					t && (t.selectedIndex, t.parentNode && t.parentNode.selectedIndex);
				},
			}),
		he.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"], function () {
			he.propFix[this.toLowerCase()] = this;
		}),
		he.fn.extend({
			addClass: function (e) {
				var t,
					n,
					r,
					i,
					o,
					s,
					a,
					u = 0;
				if (le(e))
					return this.each(function (t) {
						he(this).addClass(e.call(this, t, z(this)));
					});
				if ((t = V(e)).length)
					for (; (n = this[u++]); )
						if (((i = z(n)), (r = 1 === n.nodeType && " " + U(i) + " "))) {
							for (s = 0; (o = t[s++]); ) r.indexOf(" " + o + " ") < 0 && (r += o + " ");
							i !== (a = U(r)) && n.setAttribute("class", a);
						}
				return this;
			},
			removeClass: function (e) {
				var t,
					n,
					r,
					i,
					o,
					s,
					a,
					u = 0;
				if (le(e))
					return this.each(function (t) {
						he(this).removeClass(e.call(this, t, z(this)));
					});
				if (!arguments.length) return this.attr("class", "");
				if ((t = V(e)).length)
					for (; (n = this[u++]); )
						if (((i = z(n)), (r = 1 === n.nodeType && " " + U(i) + " "))) {
							for (s = 0; (o = t[s++]); ) for (; -1 < r.indexOf(" " + o + " "); ) r = r.replace(" " + o + " ", " ");
							i !== (a = U(r)) && n.setAttribute("class", a);
						}
				return this;
			},
			toggleClass: function (e, t) {
				var n = typeof e,
					r = "string" === n || Array.isArray(e);
				return "boolean" == typeof t && r
					? t
						? this.addClass(e)
						: this.removeClass(e)
					: le(e)
					? this.each(function (n) {
							he(this).toggleClass(e.call(this, n, z(this), t), t);
					  })
					: this.each(function () {
							var t, i, o, s;
							if (r) for (i = 0, o = he(this), s = V(e); (t = s[i++]); ) o.hasClass(t) ? o.removeClass(t) : o.addClass(t);
							else (void 0 !== e && "boolean" !== n) || ((t = z(this)) && Le.set(this, "__className__", t), this.setAttribute && this.setAttribute("class", t || !1 === e ? "" : Le.get(this, "__className__") || ""));
					  });
			},
			hasClass: function (e) {
				var t,
					n,
					r = 0;
				for (t = " " + e + " "; (n = this[r++]); ) if (1 === n.nodeType && -1 < (" " + U(z(n)) + " ").indexOf(t)) return !0;
				return !1;
			},
		});
	var Ct = /\r/g;
	he.fn.extend({
		val: function (e) {
			var t,
				n,
				r,
				i = this[0];
			return arguments.length
				? ((r = le(e)),
				  this.each(function (n) {
						var i;
						1 === this.nodeType &&
							(null == (i = r ? e.call(this, n, he(this).val()) : e)
								? (i = "")
								: "number" == typeof i
								? (i += "")
								: Array.isArray(i) &&
								  (i = he.map(i, function (e) {
										return null == e ? "" : e + "";
								  })),
							((t = he.valHooks[this.type] || he.valHooks[this.nodeName.toLowerCase()]) && "set" in t && void 0 !== t.set(this, i, "value")) || (this.value = i));
				  }))
				: i
				? (t = he.valHooks[i.type] || he.valHooks[i.nodeName.toLowerCase()]) && "get" in t && void 0 !== (n = t.get(i, "value"))
					? n
					: "string" == typeof (n = i.value)
					? n.replace(Ct, "")
					: null == n
					? ""
					: n
				: void 0;
		},
	}),
		he.extend({
			valHooks: {
				option: {
					get: function (e) {
						var t = he.find.attr(e, "value");
						return null != t ? t : U(he.text(e));
					},
				},
				select: {
					get: function (e) {
						var t,
							n,
							r,
							i = e.options,
							s = e.selectedIndex,
							a = "select-one" === e.type,
							u = a ? null : [],
							l = a ? s + 1 : i.length;
						for (r = s < 0 ? l : a ? s : 0; r < l; r++)
							if (((n = i[r]).selected || r === s) && !n.disabled && (!n.parentNode.disabled || !o(n.parentNode, "optgroup"))) {
								if (((t = he(n).val()), a)) return t;
								u.push(t);
							}
						return u;
					},
					set: function (e, t) {
						for (var n, r, i = e.options, o = he.makeArray(t), s = i.length; s--; ) ((r = i[s]).selected = -1 < he.inArray(he.valHooks.option.get(r), o)) && (n = !0);
						return n || (e.selectedIndex = -1), o;
					},
				},
			},
		}),
		he.each(["radio", "checkbox"], function () {
			(he.valHooks[this] = {
				set: function (e, t) {
					if (Array.isArray(t)) return (e.checked = -1 < he.inArray(he(e).val(), t));
				},
			}),
				ue.checkOn ||
					(he.valHooks[this].get = function (e) {
						return null === e.getAttribute("value") ? "on" : e.value;
					});
		}),
		(ue.focusin = "onfocusin" in e);
	var Et = /^(?:focusinfocus|focusoutblur)$/,
		St = function (e) {
			e.stopPropagation();
		};
	he.extend(he.event, {
		trigger: function (t, n, r, i) {
			var o,
				s,
				a,
				u,
				l,
				c,
				f,
				p,
				d = [r || fe],
				h = oe.call(t, "type") ? t.type : t,
				g = oe.call(t, "namespace") ? t.namespace.split(".") : [];
			if (
				((s = p = a = r = r || fe),
				3 !== r.nodeType &&
					8 !== r.nodeType &&
					!Et.test(h + he.event.triggered) &&
					(-1 < h.indexOf(".") && ((h = (g = h.split(".")).shift()), g.sort()),
					(l = h.indexOf(":") < 0 && "on" + h),
					((t = t[he.expando] ? t : new he.Event(h, "object" == typeof t && t)).isTrigger = i ? 2 : 3),
					(t.namespace = g.join(".")),
					(t.rnamespace = t.namespace ? new RegExp("(^|\\.)" + g.join("\\.(?:.*\\.|)") + "(\\.|$)") : null),
					(t.result = void 0),
					t.target || (t.target = r),
					(n = null == n ? [t] : he.makeArray(n, [t])),
					(f = he.event.special[h] || {}),
					i || !f.trigger || !1 !== f.trigger.apply(r, n)))
			) {
				if (!i && !f.noBubble && !ce(r)) {
					for (u = f.delegateType || h, Et.test(u + h) || (s = s.parentNode); s; s = s.parentNode) d.push(s), (a = s);
					a === (r.ownerDocument || fe) && d.push(a.defaultView || a.parentWindow || e);
				}
				for (o = 0; (s = d[o++]) && !t.isPropagationStopped(); )
					(p = s),
						(t.type = 1 < o ? u : f.bindType || h),
						(c = (Le.get(s, "events") || Object.create(null))[t.type] && Le.get(s, "handle")) && c.apply(s, n),
						(c = l && s[l]) && c.apply && je(s) && ((t.result = c.apply(s, n)), !1 === t.result && t.preventDefault());
				return (
					(t.type = h),
					i ||
						t.isDefaultPrevented() ||
						(f._default && !1 !== f._default.apply(d.pop(), n)) ||
						!je(r) ||
						(l &&
							le(r[h]) &&
							!ce(r) &&
							((a = r[l]) && (r[l] = null), (he.event.triggered = h), t.isPropagationStopped() && p.addEventListener(h, St), r[h](), t.isPropagationStopped() && p.removeEventListener(h, St), (he.event.triggered = void 0), a && (r[l] = a))),
					t.result
				);
			}
		},
		simulate: function (e, t, n) {
			var r = he.extend(new he.Event(), n, { type: e, isSimulated: !0 });
			he.event.trigger(r, null, t);
		},
	}),
		he.fn.extend({
			trigger: function (e, t) {
				return this.each(function () {
					he.event.trigger(e, t, this);
				});
			},
			triggerHandler: function (e, t) {
				var n = this[0];
				if (n) return he.event.trigger(e, t, n, !0);
			},
		}),
		ue.focusin ||
			he.each({ focus: "focusin", blur: "focusout" }, function (e, t) {
				var n = function (e) {
					he.event.simulate(t, e.target, he.event.fix(e));
				};
				he.event.special[t] = {
					setup: function () {
						var r = this.ownerDocument || this.document || this,
							i = Le.access(r, t);
						i || r.addEventListener(e, n, !0), Le.access(r, t, (i || 0) + 1);
					},
					teardown: function () {
						var r = this.ownerDocument || this.document || this,
							i = Le.access(r, t) - 1;
						i ? Le.access(r, t, i) : (r.removeEventListener(e, n, !0), Le.remove(r, t));
					},
				};
			});
	var kt = e.location,
		At = { guid: Date.now() },
		Dt = /\?/;
	he.parseXML = function (t) {
		var n;
		if (!t || "string" != typeof t) return null;
		try {
			n = new e.DOMParser().parseFromString(t, "text/xml");
		} catch (t) {
			n = void 0;
		}
		return (n && !n.getElementsByTagName("parsererror").length) || he.error("Invalid XML: " + t), n;
	};
	var Nt = /\[\]$/,
		jt = /\r?\n/g,
		Lt = /^(?:submit|button|image|reset|file)$/i,
		qt = /^(?:input|select|textarea|keygen)/i;
	(he.param = function (e, t) {
		var n,
			r = [],
			i = function (e, t) {
				var n = le(t) ? t() : t;
				r[r.length] = encodeURIComponent(e) + "=" + encodeURIComponent(null == n ? "" : n);
			};
		if (null == e) return "";
		if (Array.isArray(e) || (e.jquery && !he.isPlainObject(e)))
			he.each(e, function () {
				i(this.name, this.value);
			});
		else for (n in e) X(n, e[n], t, i);
		return r.join("&");
	}),
		he.fn.extend({
			serialize: function () {
				return he.param(this.serializeArray());
			},
			serializeArray: function () {
				return this.map(function () {
					var e = he.prop(this, "elements");
					return e ? he.makeArray(e) : this;
				})
					.filter(function () {
						var e = this.type;
						return this.name && !he(this).is(":disabled") && qt.test(this.nodeName) && !Lt.test(e) && (this.checked || !ze.test(e));
					})
					.map(function (e, t) {
						var n = he(this).val();
						return null == n
							? null
							: Array.isArray(n)
							? he.map(n, function (e) {
									return { name: t.name, value: e.replace(jt, "\r\n") };
							  })
							: { name: t.name, value: n.replace(jt, "\r\n") };
					})
					.get();
			},
		});
	var _t = /%20/g,
		Ot = /#.*$/,
		Rt = /([?&])_=[^&]*/,
		It = /^(.*?):[ \t]*([^\r\n]*)$/gm,
		Ht = /^(?:GET|HEAD)$/,
		Mt = /^\/\//,
		Pt = {},
		Ft = {},
		Wt = "*/".concat("*"),
		Bt = fe.createElement("a");
	(Bt.href = kt.href),
		he.extend({
			active: 0,
			lastModified: {},
			etag: {},
			ajaxSettings: {
				url: kt.href,
				type: "GET",
				isLocal: /^(?:about|app|app-storage|.+-extension|file|res|widget):$/.test(kt.protocol),
				global: !0,
				processData: !0,
				async: !0,
				contentType: "application/x-www-form-urlencoded; charset=UTF-8",
				accepts: { "*": Wt, text: "text/plain", html: "text/html", xml: "application/xml, text/xml", json: "application/json, text/javascript" },
				contents: { xml: /\bxml\b/, html: /\bhtml/, json: /\bjson\b/ },
				responseFields: { xml: "responseXML", text: "responseText", json: "responseJSON" },
				converters: { "* text": String, "text html": !0, "text json": JSON.parse, "text xml": he.parseXML },
				flatOptions: { url: !0, context: !0 },
			},
			ajaxSetup: function (e, t) {
				return t ? Q(Q(e, he.ajaxSettings), t) : Q(he.ajaxSettings, e);
			},
			ajaxPrefilter: G(Pt),
			ajaxTransport: G(Ft),
			ajax: function (t, n) {
				function r(t, n, r, a) {
					var l,
						p,
						d,
						x,
						w,
						T = n;
					c ||
						((c = !0),
						u && e.clearTimeout(u),
						(i = void 0),
						(s = a || ""),
						(C.readyState = 0 < t ? 4 : 0),
						(l = (200 <= t && t < 300) || 304 === t),
						r &&
							(x = (function (e, t, n) {
								for (var r, i, o, s, a = e.contents, u = e.dataTypes; "*" === u[0]; ) u.shift(), void 0 === r && (r = e.mimeType || t.getResponseHeader("Content-Type"));
								if (r)
									for (i in a)
										if (a[i] && a[i].test(r)) {
											u.unshift(i);
											break;
										}
								if (u[0] in n) o = u[0];
								else {
									for (i in n) {
										if (!u[0] || e.converters[i + " " + u[0]]) {
											o = i;
											break;
										}
										s || (s = i);
									}
									o = o || s;
								}
								if (o) return o !== u[0] && u.unshift(o), n[o];
							})(h, C, r)),
						!l && -1 < he.inArray("script", h.dataTypes) && (h.converters["text script"] = function () {}),
						(x = (function (e, t, n, r) {
							var i,
								o,
								s,
								a,
								u,
								l = {},
								c = e.dataTypes.slice();
							if (c[1]) for (s in e.converters) l[s.toLowerCase()] = e.converters[s];
							for (o = c.shift(); o; )
								if ((e.responseFields[o] && (n[e.responseFields[o]] = t), !u && r && e.dataFilter && (t = e.dataFilter(t, e.dataType)), (u = o), (o = c.shift())))
									if ("*" === o) o = u;
									else if ("*" !== u && u !== o) {
										if (!(s = l[u + " " + o] || l["* " + o]))
											for (i in l)
												if ((a = i.split(" "))[1] === o && (s = l[u + " " + a[0]] || l["* " + a[0]])) {
													!0 === s ? (s = l[i]) : !0 !== l[i] && ((o = a[0]), c.unshift(a[1]));
													break;
												}
										if (!0 !== s)
											if (s && e.throws) t = s(t);
											else
												try {
													t = s(t);
												} catch (e) {
													return { state: "parsererror", error: s ? e : "No conversion from " + u + " to " + o };
												}
									}
							return { state: "success", data: t };
						})(h, x, C, l)),
						l
							? (h.ifModified && ((w = C.getResponseHeader("Last-Modified")) && (he.lastModified[o] = w), (w = C.getResponseHeader("etag")) && (he.etag[o] = w)),
							  204 === t || "HEAD" === h.type ? (T = "nocontent") : 304 === t ? (T = "notmodified") : ((T = x.state), (p = x.data), (l = !(d = x.error))))
							: ((d = T), (!t && T) || ((T = "error"), t < 0 && (t = 0))),
						(C.status = t),
						(C.statusText = (n || T) + ""),
						l ? m.resolveWith(g, [p, T, C]) : m.rejectWith(g, [C, T, d]),
						C.statusCode(b),
						(b = void 0),
						f && v.trigger(l ? "ajaxSuccess" : "ajaxError", [C, h, l ? p : d]),
						y.fireWith(g, [C, T]),
						f && (v.trigger("ajaxComplete", [C, h]), --he.active || he.event.trigger("ajaxStop")));
				}
				"object" == typeof t && ((n = t), (t = void 0)), (n = n || {});
				var i,
					o,
					s,
					a,
					u,
					l,
					c,
					f,
					p,
					d,
					h = he.ajaxSetup({}, n),
					g = h.context || h,
					v = h.context && (g.nodeType || g.jquery) ? he(g) : he.event,
					m = he.Deferred(),
					y = he.Callbacks("once memory"),
					b = h.statusCode || {},
					x = {},
					w = {},
					T = "canceled",
					C = {
						readyState: 0,
						getResponseHeader: function (e) {
							var t;
							if (c) {
								if (!a) for (a = {}; (t = It.exec(s)); ) a[t[1].toLowerCase() + " "] = (a[t[1].toLowerCase() + " "] || []).concat(t[2]);
								t = a[e.toLowerCase() + " "];
							}
							return null == t ? null : t.join(", ");
						},
						getAllResponseHeaders: function () {
							return c ? s : null;
						},
						setRequestHeader: function (e, t) {
							return null == c && ((e = w[e.toLowerCase()] = w[e.toLowerCase()] || e), (x[e] = t)), this;
						},
						overrideMimeType: function (e) {
							return null == c && (h.mimeType = e), this;
						},
						statusCode: function (e) {
							var t;
							if (e)
								if (c) C.always(e[C.status]);
								else for (t in e) b[t] = [b[t], e[t]];
							return this;
						},
						abort: function (e) {
							var t = e || T;
							return i && i.abort(t), r(0, t), this;
						},
					};
				if ((m.promise(C), (h.url = ((t || h.url || kt.href) + "").replace(Mt, kt.protocol + "//")), (h.type = n.method || n.type || h.method || h.type), (h.dataTypes = (h.dataType || "*").toLowerCase().match(Ee) || [""]), null == h.crossDomain)) {
					l = fe.createElement("a");
					try {
						(l.href = h.url), (l.href = l.href), (h.crossDomain = Bt.protocol + "//" + Bt.host != l.protocol + "//" + l.host);
					} catch (t) {
						h.crossDomain = !0;
					}
				}
				if ((h.data && h.processData && "string" != typeof h.data && (h.data = he.param(h.data, h.traditional)), Y(Pt, h, n, C), c)) return C;
				for (p in ((f = he.event && h.global) && 0 == he.active++ && he.event.trigger("ajaxStart"),
				(h.type = h.type.toUpperCase()),
				(h.hasContent = !Ht.test(h.type)),
				(o = h.url.replace(Ot, "")),
				h.hasContent
					? h.data && h.processData && 0 === (h.contentType || "").indexOf("application/x-www-form-urlencoded") && (h.data = h.data.replace(_t, "+"))
					: ((d = h.url.slice(o.length)),
					  h.data && (h.processData || "string" == typeof h.data) && ((o += (Dt.test(o) ? "&" : "?") + h.data), delete h.data),
					  !1 === h.cache && ((o = o.replace(Rt, "$1")), (d = (Dt.test(o) ? "&" : "?") + "_=" + At.guid++ + d)),
					  (h.url = o + d)),
				h.ifModified && (he.lastModified[o] && C.setRequestHeader("If-Modified-Since", he.lastModified[o]), he.etag[o] && C.setRequestHeader("If-None-Match", he.etag[o])),
				((h.data && h.hasContent && !1 !== h.contentType) || n.contentType) && C.setRequestHeader("Content-Type", h.contentType),
				C.setRequestHeader("Accept", h.dataTypes[0] && h.accepts[h.dataTypes[0]] ? h.accepts[h.dataTypes[0]] + ("*" !== h.dataTypes[0] ? ", " + Wt + "; q=0.01" : "") : h.accepts["*"]),
				h.headers))
					C.setRequestHeader(p, h.headers[p]);
				if (h.beforeSend && (!1 === h.beforeSend.call(g, C, h) || c)) return C.abort();
				if (((T = "abort"), y.add(h.complete), C.done(h.success), C.fail(h.error), (i = Y(Ft, h, n, C)))) {
					if (((C.readyState = 1), f && v.trigger("ajaxSend", [C, h]), c)) return C;
					h.async &&
						0 < h.timeout &&
						(u = e.setTimeout(function () {
							C.abort("timeout");
						}, h.timeout));
					try {
						(c = !1), i.send(x, r);
					} catch (t) {
						if (c) throw t;
						r(-1, t);
					}
				} else r(-1, "No Transport");
				return C;
			},
			getJSON: function (e, t, n) {
				return he.get(e, t, n, "json");
			},
			getScript: function (e, t) {
				return he.get(e, void 0, t, "script");
			},
		}),
		he.each(["get", "post"], function (e, t) {
			he[t] = function (e, n, r, i) {
				return le(n) && ((i = i || r), (r = n), (n = void 0)), he.ajax(he.extend({ url: e, type: t, dataType: i, data: n, success: r }, he.isPlainObject(e) && e));
			};
		}),
		he.ajaxPrefilter(function (e) {
			var t;
			for (t in e.headers) "content-type" === t.toLowerCase() && (e.contentType = e.headers[t] || "");
		}),
		(he._evalUrl = function (e, t, n) {
			return he.ajax({
				url: e,
				type: "GET",
				dataType: "script",
				cache: !0,
				async: !1,
				global: !1,
				converters: { "text script": function () {} },
				dataFilter: function (e) {
					he.globalEval(e, t, n);
				},
			});
		}),
		he.fn.extend({
			wrapAll: function (e) {
				var t;
				return (
					this[0] &&
						(le(e) && (e = e.call(this[0])),
						(t = he(e, this[0].ownerDocument).eq(0).clone(!0)),
						this[0].parentNode && t.insertBefore(this[0]),
						t
							.map(function () {
								for (var e = this; e.firstElementChild; ) e = e.firstElementChild;
								return e;
							})
							.append(this)),
					this
				);
			},
			wrapInner: function (e) {
				return le(e)
					? this.each(function (t) {
							he(this).wrapInner(e.call(this, t));
					  })
					: this.each(function () {
							var t = he(this),
								n = t.contents();
							n.length ? n.wrapAll(e) : t.append(e);
					  });
			},
			wrap: function (e) {
				var t = le(e);
				return this.each(function (n) {
					he(this).wrapAll(t ? e.call(this, n) : e);
				});
			},
			unwrap: function (e) {
				return (
					this.parent(e)
						.not("body")
						.each(function () {
							he(this).replaceWith(this.childNodes);
						}),
					this
				);
			},
		}),
		(he.expr.pseudos.hidden = function (e) {
			return !he.expr.pseudos.visible(e);
		}),
		(he.expr.pseudos.visible = function (e) {
			return !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length);
		}),
		(he.ajaxSettings.xhr = function () {
			try {
				return new e.XMLHttpRequest();
			} catch (e) {}
		});
	var $t = { 0: 200, 1223: 204 },
		Ut = he.ajaxSettings.xhr();
	(ue.cors = !!Ut && "withCredentials" in Ut),
		(ue.ajax = Ut = !!Ut),
		he.ajaxTransport(function (t) {
			var n, r;
			if (ue.cors || (Ut && !t.crossDomain))
				return {
					send: function (i, o) {
						var s,
							a = t.xhr();
						if ((a.open(t.type, t.url, t.async, t.username, t.password), t.xhrFields)) for (s in t.xhrFields) a[s] = t.xhrFields[s];
						for (s in (t.mimeType && a.overrideMimeType && a.overrideMimeType(t.mimeType), t.crossDomain || i["X-Requested-With"] || (i["X-Requested-With"] = "XMLHttpRequest"), i)) a.setRequestHeader(s, i[s]);
						(n = function (e) {
							return function () {
								n &&
									((n = r = a.onload = a.onerror = a.onabort = a.ontimeout = a.onreadystatechange = null),
									"abort" === e
										? a.abort()
										: "error" === e
										? "number" != typeof a.status
											? o(0, "error")
											: o(a.status, a.statusText)
										: o($t[a.status] || a.status, a.statusText, "text" !== (a.responseType || "text") || "string" != typeof a.responseText ? { binary: a.response } : { text: a.responseText }, a.getAllResponseHeaders()));
							};
						}),
							(a.onload = n()),
							(r = a.onerror = a.ontimeout = n("error")),
							void 0 !== a.onabort
								? (a.onabort = r)
								: (a.onreadystatechange = function () {
										4 === a.readyState &&
											e.setTimeout(function () {
												n && r();
											});
								  }),
							(n = n("abort"));
						try {
							a.send((t.hasContent && t.data) || null);
						} catch (i) {
							if (n) throw i;
						}
					},
					abort: function () {
						n && n();
					},
				};
		}),
		he.ajaxPrefilter(function (e) {
			e.crossDomain && (e.contents.script = !1);
		}),
		he.ajaxSetup({
			accepts: { script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript" },
			contents: { script: /\b(?:java|ecma)script\b/ },
			converters: {
				"text script": function (e) {
					return he.globalEval(e), e;
				},
			},
		}),
		he.ajaxPrefilter("script", function (e) {
			void 0 === e.cache && (e.cache = !1), e.crossDomain && (e.type = "GET");
		}),
		he.ajaxTransport("script", function (e) {
			var t, n;
			if (e.crossDomain || e.scriptAttrs)
				return {
					send: function (r, i) {
						(t = he("<script>")
							.attr(e.scriptAttrs || {})
							.prop({ charset: e.scriptCharset, src: e.url })
							.on(
								"load error",
								(n = function (e) {
									t.remove(), (n = null), e && i("error" === e.type ? 404 : 200, e.type);
								})
							)),
							fe.head.appendChild(t[0]);
					},
					abort: function () {
						n && n();
					},
				};
		});
	var zt,
		Vt = [],
		Xt = /(=)\?(?=&|$)|\?\?/;
	he.ajaxSetup({
		jsonp: "callback",
		jsonpCallback: function () {
			var e = Vt.pop() || he.expando + "_" + At.guid++;
			return (this[e] = !0), e;
		},
	}),
		he.ajaxPrefilter("json jsonp", function (t, n, r) {
			var i,
				o,
				s,
				a = !1 !== t.jsonp && (Xt.test(t.url) ? "url" : "string" == typeof t.data && 0 === (t.contentType || "").indexOf("application/x-www-form-urlencoded") && Xt.test(t.data) && "data");
			if (a || "jsonp" === t.dataTypes[0])
				return (
					(i = t.jsonpCallback = le(t.jsonpCallback) ? t.jsonpCallback() : t.jsonpCallback),
					a ? (t[a] = t[a].replace(Xt, "$1" + i)) : !1 !== t.jsonp && (t.url += (Dt.test(t.url) ? "&" : "?") + t.jsonp + "=" + i),
					(t.converters["script json"] = function () {
						return s || he.error(i + " was not called"), s[0];
					}),
					(t.dataTypes[0] = "json"),
					(o = e[i]),
					(e[i] = function () {
						s = arguments;
					}),
					r.always(function () {
						void 0 === o ? he(e).removeProp(i) : (e[i] = o), t[i] && ((t.jsonpCallback = n.jsonpCallback), Vt.push(i)), s && le(o) && o(s[0]), (s = o = void 0);
					}),
					"script"
				);
		}),
		(ue.createHTMLDocument = (((zt = fe.implementation.createHTMLDocument("").body).innerHTML = "<form></form><form></form>"), 2 === zt.childNodes.length)),
		(he.parseHTML = function (e, t, n) {
			return "string" != typeof e
				? []
				: ("boolean" == typeof t && ((n = t), (t = !1)),
				  t || (ue.createHTMLDocument ? (((r = (t = fe.implementation.createHTMLDocument("")).createElement("base")).href = fe.location.href), t.head.appendChild(r)) : (t = fe)),
				  (o = !n && []),
				  (i = be.exec(e)) ? [t.createElement(i[1])] : ((i = x([e], t, o)), o && o.length && he(o).remove(), he.merge([], i.childNodes)));
			var r, i, o;
		}),
		(he.fn.load = function (e, t, n) {
			var r,
				i,
				o,
				s = this,
				a = e.indexOf(" ");
			return (
				-1 < a && ((r = U(e.slice(a))), (e = e.slice(0, a))),
				le(t) ? ((n = t), (t = void 0)) : t && "object" == typeof t && (i = "POST"),
				0 < s.length &&
					he
						.ajax({ url: e, type: i || "GET", dataType: "html", data: t })
						.done(function (e) {
							(o = arguments), s.html(r ? he("<div>").append(he.parseHTML(e)).find(r) : e);
						})
						.always(
							n &&
								function (e, t) {
									s.each(function () {
										n.apply(this, o || [e.responseText, t, e]);
									});
								}
						),
				this
			);
		}),
		(he.expr.pseudos.animated = function (e) {
			return he.grep(he.timers, function (t) {
				return e === t.elem;
			}).length;
		}),
		(he.offset = {
			setOffset: function (e, t, n) {
				var r,
					i,
					o,
					s,
					a,
					u,
					l = he.css(e, "position"),
					c = he(e),
					f = {};
				"static" === l && (e.style.position = "relative"),
					(a = c.offset()),
					(o = he.css(e, "top")),
					(u = he.css(e, "left")),
					("absolute" === l || "fixed" === l) && -1 < (o + u).indexOf("auto") ? ((s = (r = c.position()).top), (i = r.left)) : ((s = parseFloat(o) || 0), (i = parseFloat(u) || 0)),
					le(t) && (t = t.call(e, n, he.extend({}, a))),
					null != t.top && (f.top = t.top - a.top + s),
					null != t.left && (f.left = t.left - a.left + i),
					"using" in t ? t.using.call(e, f) : ("number" == typeof f.top && (f.top += "px"), "number" == typeof f.left && (f.left += "px"), c.css(f));
			},
		}),
		he.fn.extend({
			offset: function (e) {
				if (arguments.length)
					return void 0 === e
						? this
						: this.each(function (t) {
								he.offset.setOffset(this, e, t);
						  });
				var t,
					n,
					r = this[0];
				return r ? (r.getClientRects().length ? ((t = r.getBoundingClientRect()), (n = r.ownerDocument.defaultView), { top: t.top + n.pageYOffset, left: t.left + n.pageXOffset }) : { top: 0, left: 0 }) : void 0;
			},
			position: function () {
				if (this[0]) {
					var e,
						t,
						n,
						r = this[0],
						i = { top: 0, left: 0 };
					if ("fixed" === he.css(r, "position")) t = r.getBoundingClientRect();
					else {
						for (t = this.offset(), n = r.ownerDocument, e = r.offsetParent || n.documentElement; e && (e === n.body || e === n.documentElement) && "static" === he.css(e, "position"); ) e = e.parentNode;
						e && e !== r && 1 === e.nodeType && (((i = he(e).offset()).top += he.css(e, "borderTopWidth", !0)), (i.left += he.css(e, "borderLeftWidth", !0)));
					}
					return { top: t.top - i.top - he.css(r, "marginTop", !0), left: t.left - i.left - he.css(r, "marginLeft", !0) };
				}
			},
			offsetParent: function () {
				return this.map(function () {
					for (var e = this.offsetParent; e && "static" === he.css(e, "position"); ) e = e.offsetParent;
					return e || Me;
				});
			},
		}),
		he.each({ scrollLeft: "pageXOffset", scrollTop: "pageYOffset" }, function (e, t) {
			var n = "pageYOffset" === t;
			he.fn[e] = function (r) {
				return Ae(
					this,
					function (e, r, i) {
						var o;
						if ((ce(e) ? (o = e) : 9 === e.nodeType && (o = e.defaultView), void 0 === i)) return o ? o[t] : e[r];
						o ? o.scrollTo(n ? o.pageXOffset : i, n ? i : o.pageYOffset) : (e[r] = i);
					},
					e,
					r,
					arguments.length
				);
			};
		}),
		he.each(["top", "left"], function (e, t) {
			he.cssHooks[t] = _(ue.pixelPosition, function (e, n) {
				if (n) return (n = q(e, t)), nt.test(n) ? he(e).position()[t] + "px" : n;
			});
		}),
		he.each({ Height: "height", Width: "width" }, function (e, t) {
			he.each({ padding: "inner" + e, content: t, "": "outer" + e }, function (n, r) {
				he.fn[r] = function (i, o) {
					var s = arguments.length && (n || "boolean" != typeof i),
						a = n || (!0 === i || !0 === o ? "margin" : "border");
					return Ae(
						this,
						function (t, n, i) {
							var o;
							return ce(t)
								? 0 === r.indexOf("outer")
									? t["inner" + e]
									: t.document.documentElement["client" + e]
								: 9 === t.nodeType
								? ((o = t.documentElement), Math.max(t.body["scroll" + e], o["scroll" + e], t.body["offset" + e], o["offset" + e], o["client" + e]))
								: void 0 === i
								? he.css(t, n, a)
								: he.style(t, n, i, a);
						},
						t,
						s ? i : void 0,
						s
					);
				};
			});
		}),
		he.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], function (e, t) {
			he.fn[t] = function (e) {
				return this.on(t, e);
			};
		}),
		he.fn.extend({
			bind: function (e, t, n) {
				return this.on(e, null, t, n);
			},
			unbind: function (e, t) {
				return this.off(e, null, t);
			},
			delegate: function (e, t, n, r) {
				return this.on(t, e, n, r);
			},
			undelegate: function (e, t, n) {
				return 1 === arguments.length ? this.off(e, "**") : this.off(t, e || "**", n);
			},
			hover: function (e, t) {
				return this.mouseenter(e).mouseleave(t || e);
			},
		}),
		he.each("blur focus focusin focusout resize scroll click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup contextmenu".split(" "), function (e, t) {
			he.fn[t] = function (e, n) {
				return 0 < arguments.length ? this.on(t, null, e, n) : this.trigger(t);
			};
		});
	var Gt = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g;
	(he.proxy = function (e, t) {
		var n, r, i;
		if (("string" == typeof t && ((n = e[t]), (t = e), (e = n)), le(e)))
			return (
				(r = Z.call(arguments, 2)),
				((i = function () {
					return e.apply(t || this, r.concat(Z.call(arguments)));
				}).guid = e.guid = e.guid || he.guid++),
				i
			);
	}),
		(he.holdReady = function (e) {
			e ? he.readyWait++ : he.ready(!0);
		}),
		(he.isArray = Array.isArray),
		(he.parseJSON = JSON.parse),
		(he.nodeName = o),
		(he.isFunction = le),
		(he.isWindow = ce),
		(he.camelCase = d),
		(he.type = r),
		(he.now = Date.now),
		(he.isNumeric = function (e) {
			var t = he.type(e);
			return ("number" === t || "string" === t) && !isNaN(e - parseFloat(e));
		}),
		(he.trim = function (e) {
			return null == e ? "" : (e + "").replace(Gt, "");
		}),
		"function" == typeof define &&
			define.amd &&
			define("jquery", [], function () {
				return he;
			});
	var Yt = e.jQuery,
		Qt = e.$;
	return (
		(he.noConflict = function (t) {
			return e.$ === he && (e.$ = Qt), t && e.jQuery === he && (e.jQuery = Yt), he;
		}),
		void 0 === t && (e.jQuery = e.$ = he),
		he
	);
}),
	(function () {
		"use strict";
		function e(e) {
			try {
				return (e.defaultView && e.defaultView.frameElement) || null;
			} catch (e) {
				return null;
			}
		}
		function t(e) {
			(this.time = e.time), (this.target = e.target), (this.rootBounds = c(e.rootBounds)), (this.boundingClientRect = c(e.boundingClientRect)), (this.intersectionRect = c(e.intersectionRect || l())), (this.isIntersecting = !!e.intersectionRect);
			var t = this.boundingClientRect,
				n = t.width * t.height,
				r = this.intersectionRect,
				i = r.width * r.height;
			this.intersectionRatio = n ? Number((i / n).toFixed(4)) : this.isIntersecting ? 1 : 0;
		}
		function n(e, t) {
			var n = t || {};
			if ("function" != typeof e) throw new Error("callback must be a function");
			if (n.root && 1 != n.root.nodeType) throw new Error("root must be an Element");
			(this._checkForIntersections = i(this._checkForIntersections.bind(this), this.THROTTLE_TIMEOUT)),
				(this._callback = e),
				(this._observationTargets = []),
				(this._queuedEntries = []),
				(this._rootMarginValues = this._parseRootMargin(n.rootMargin)),
				(this.thresholds = this._initThresholds(n.threshold)),
				(this.root = n.root || null),
				(this.rootMargin = this._rootMarginValues
					.map(function (e) {
						return e.value + e.unit;
					})
					.join(" ")),
				(this._monitoringDocuments = []),
				(this._monitoringUnsubscribes = []);
		}
		function r() {
			return window.performance && performance.now && performance.now();
		}
		function i(e, t) {
			var n = null;
			return function () {
				n ||
					(n = setTimeout(function () {
						e(), (n = null);
					}, t));
			};
		}
		function o(e, t, n, r) {
			"function" == typeof e.addEventListener ? e.addEventListener(t, n, r || !1) : "function" == typeof e.attachEvent && e.attachEvent("on" + t, n);
		}
		function s(e, t, n, r) {
			"function" == typeof e.removeEventListener ? e.removeEventListener(t, n, r || !1) : "function" == typeof e.detatchEvent && e.detatchEvent("on" + t, n);
		}
		function a(e, t) {
			var n = Math.max(e.top, t.top),
				r = Math.min(e.bottom, t.bottom),
				i = Math.max(e.left, t.left),
				o = Math.min(e.right, t.right),
				s = o - i,
				a = r - n;
			return (s >= 0 && a >= 0 && { top: n, bottom: r, left: i, right: o, width: s, height: a }) || null;
		}
		function u(e) {
			var t;
			try {
				t = e.getBoundingClientRect();
			} catch (e) {}
			return t ? ((t.width && t.height) || (t = { top: t.top, right: t.right, bottom: t.bottom, left: t.left, width: t.right - t.left, height: t.bottom - t.top }), t) : l();
		}
		function l() {
			return { top: 0, bottom: 0, left: 0, right: 0, width: 0, height: 0 };
		}
		function c(e) {
			return !e || "x" in e ? e : { top: e.top, y: e.top, bottom: e.bottom, left: e.left, x: e.left, right: e.right, width: e.width, height: e.height };
		}
		function f(e, t) {
			var n = t.top - e.top,
				r = t.left - e.left;
			return { top: n, left: r, height: t.height, width: t.width, bottom: n + t.height, right: r + t.width };
		}
		function p(e, t) {
			for (var n = t; n; ) {
				if (n == e) return !0;
				n = d(n);
			}
			return !1;
		}
		function d(t) {
			var n = t.parentNode;
			return 9 == t.nodeType && t != h ? e(t) : n && 11 == n.nodeType && n.host ? n.host : n && n.assignedSlot ? n.assignedSlot.parentNode : n;
		}
		if ("object" == typeof window)
			if ("IntersectionObserver" in window && "IntersectionObserverEntry" in window && "intersectionRatio" in window.IntersectionObserverEntry.prototype)
				"isIntersecting" in window.IntersectionObserverEntry.prototype ||
					Object.defineProperty(window.IntersectionObserverEntry.prototype, "isIntersecting", {
						get: function () {
							return this.intersectionRatio > 0;
						},
					});
			else {
				var h = (function (t) {
						for (var n = t, r = e(n); r; ) (n = r.ownerDocument), (r = e(n));
						return n;
					})(window.document),
					g = [],
					v = null,
					m = null;
				(n.prototype.THROTTLE_TIMEOUT = 100),
					(n.prototype.POLL_INTERVAL = null),
					(n.prototype.USE_MUTATION_OBSERVER = !0),
					(n._setupCrossOriginUpdater = function () {
						return (
							v ||
								(v = function (e, t) {
									(m = e && t ? f(e, t) : l()),
										g.forEach(function (e) {
											e._checkForIntersections();
										});
								}),
							v
						);
					}),
					(n._resetCrossOriginUpdater = function () {
						(v = null), (m = null);
					}),
					(n.prototype.observe = function (e) {
						var t = this._observationTargets.some(function (t) {
							return t.element == e;
						});
						if (!t) {
							if (!e || 1 != e.nodeType) throw new Error("target must be an Element");
							this._registerInstance(), this._observationTargets.push({ element: e, entry: null }), this._monitorIntersections(e.ownerDocument), this._checkForIntersections();
						}
					}),
					(n.prototype.unobserve = function (e) {
						(this._observationTargets = this._observationTargets.filter(function (t) {
							return t.element != e;
						})),
							this._unmonitorIntersections(e.ownerDocument),
							0 == this._observationTargets.length && this._unregisterInstance();
					}),
					(n.prototype.disconnect = function () {
						(this._observationTargets = []), this._unmonitorAllIntersections(), this._unregisterInstance();
					}),
					(n.prototype.takeRecords = function () {
						var e = this._queuedEntries.slice();
						return (this._queuedEntries = []), e;
					}),
					(n.prototype._initThresholds = function (e) {
						var t = e || [0];
						return (
							Array.isArray(t) || (t = [t]),
							t.sort().filter(function (e, t, n) {
								if ("number" != typeof e || isNaN(e) || e < 0 || e > 1) throw new Error("threshold must be a number between 0 and 1 inclusively");
								return e !== n[t - 1];
							})
						);
					}),
					(n.prototype._parseRootMargin = function (e) {
						var t = e || "0px",
							n = t.split(/\s+/).map(function (e) {
								var t = /^(-?\d*\.?\d+)(px|%)$/.exec(e);
								if (!t) throw new Error("rootMargin must be specified in pixels or percent");
								return { value: parseFloat(t[1]), unit: t[2] };
							});
						return (n[1] = n[1] || n[0]), (n[2] = n[2] || n[0]), (n[3] = n[3] || n[1]), n;
					}),
					(n.prototype._monitorIntersections = function (t) {
						var n = t.defaultView;
						if (n && -1 == this._monitoringDocuments.indexOf(t)) {
							var r = this._checkForIntersections,
								i = null,
								a = null;
							if (
								(this.POLL_INTERVAL
									? (i = n.setInterval(r, this.POLL_INTERVAL))
									: (o(n, "resize", r, !0), o(t, "scroll", r, !0), this.USE_MUTATION_OBSERVER && "MutationObserver" in n && ((a = new n.MutationObserver(r)), a.observe(t, { attributes: !0, childList: !0, characterData: !0, subtree: !0 }))),
								this._monitoringDocuments.push(t),
								this._monitoringUnsubscribes.push(function () {
									var e = t.defaultView;
									e && (i && e.clearInterval(i), s(e, "resize", r, !0)), s(t, "scroll", r, !0), a && a.disconnect();
								}),
								t != ((this.root && this.root.ownerDocument) || h))
							) {
								var u = e(t);
								u && this._monitorIntersections(u.ownerDocument);
							}
						}
					}),
					(n.prototype._unmonitorIntersections = function (t) {
						var n = this._monitoringDocuments.indexOf(t);
						if (-1 != n) {
							var r = (this.root && this.root.ownerDocument) || h,
								i = this._observationTargets.some(function (n) {
									var i = n.element.ownerDocument;
									if (i == t) return !0;
									for (; i && i != r; ) {
										var o = e(i);
										if (((i = o && o.ownerDocument), i == t)) return !0;
									}
									return !1;
								});
							if (!i) {
								var o = this._monitoringUnsubscribes[n];
								if ((this._monitoringDocuments.splice(n, 1), this._monitoringUnsubscribes.splice(n, 1), o(), t != r)) {
									var s = e(t);
									s && this._unmonitorIntersections(s.ownerDocument);
								}
							}
						}
					}),
					(n.prototype._unmonitorAllIntersections = function () {
						var e = this._monitoringUnsubscribes.slice(0);
						(this._monitoringDocuments.length = 0), (this._monitoringUnsubscribes.length = 0);
						for (var t = 0; t < e.length; t++) e[t]();
					}),
					(n.prototype._checkForIntersections = function () {
						if (this.root || !v || m) {
							var e = this._rootIsInDom(),
								n = e ? this._getRootRect() : l();
							this._observationTargets.forEach(function (i) {
								var o = i.element,
									s = u(o),
									a = this._rootContainsTarget(o),
									l = i.entry,
									c = e && a && this._computeTargetAndRootIntersection(o, s, n),
									f = (i.entry = new t({ time: r(), target: o, boundingClientRect: s, rootBounds: v && !this.root ? null : n, intersectionRect: c }));
								l ? (e && a ? this._hasCrossedThreshold(l, f) && this._queuedEntries.push(f) : l && l.isIntersecting && this._queuedEntries.push(f)) : this._queuedEntries.push(f);
							}, this),
								this._queuedEntries.length && this._callback(this.takeRecords(), this);
						}
					}),
					(n.prototype._computeTargetAndRootIntersection = function (e, t, n) {
						if ("none" != window.getComputedStyle(e).display) {
							for (var r = t, i = d(e), o = !1; !o && i; ) {
								var s = null,
									l = 1 == i.nodeType ? window.getComputedStyle(i) : {};
								if ("none" == l.display) return null;
								if (i == this.root || 9 == i.nodeType)
									if (((o = !0), i == this.root || i == h)) v && !this.root ? (!m || (0 == m.width && 0 == m.height) ? ((i = null), (s = null), (r = null)) : (s = m)) : (s = n);
									else {
										var c = d(i),
											p = c && u(c),
											g = c && this._computeTargetAndRootIntersection(c, p, n);
										p && g ? ((i = c), (s = f(p, g))) : ((i = null), (r = null));
									}
								else {
									var y = i.ownerDocument;
									i != y.body && i != y.documentElement && "visible" != l.overflow && (s = u(i));
								}
								if ((s && (r = a(s, r)), !r)) break;
								i = i && d(i);
							}
							return r;
						}
					}),
					(n.prototype._getRootRect = function () {
						var e;
						if (this.root) e = u(this.root);
						else {
							var t = h.documentElement,
								n = h.body;
							e = { top: 0, left: 0, right: t.clientWidth || n.clientWidth, width: t.clientWidth || n.clientWidth, bottom: t.clientHeight || n.clientHeight, height: t.clientHeight || n.clientHeight };
						}
						return this._expandRectByRootMargin(e);
					}),
					(n.prototype._expandRectByRootMargin = function (e) {
						var t = this._rootMarginValues.map(function (t, n) {
								return "px" == t.unit ? t.value : (t.value * (n % 2 ? e.width : e.height)) / 100;
							}),
							n = { top: e.top - t[0], right: e.right + t[1], bottom: e.bottom + t[2], left: e.left - t[3] };
						return (n.width = n.right - n.left), (n.height = n.bottom - n.top), n;
					}),
					(n.prototype._hasCrossedThreshold = function (e, t) {
						var n = e && e.isIntersecting ? e.intersectionRatio || 0 : -1,
							r = t.isIntersecting ? t.intersectionRatio || 0 : -1;
						if (n !== r)
							for (var i = 0; i < this.thresholds.length; i++) {
								var o = this.thresholds[i];
								if (o == n || o == r || o < n != o < r) return !0;
							}
					}),
					(n.prototype._rootIsInDom = function () {
						return !this.root || p(h, this.root);
					}),
					(n.prototype._rootContainsTarget = function (e) {
						return p(this.root || h, e) && (!this.root || this.root.ownerDocument == e.ownerDocument);
					}),
					(n.prototype._registerInstance = function () {
						g.indexOf(this) < 0 && g.push(this);
					}),
					(n.prototype._unregisterInstance = function () {
						var e = g.indexOf(this);
						-1 != e && g.splice(e, 1);
					}),
					(window.IntersectionObserver = n),
					(window.IntersectionObserverEntry = t);
			}
	})();

// mustache.js
// This file has been generated from mustache.mjs
(function (global, factory) {
	typeof exports === "object" && typeof module !== "undefined" ? (module.exports = factory()) : typeof define === "function" && define.amd ? define(factory) : ((global = global || self), (global.Mustache = factory()));
})(this, function () {
	"use strict";

	/*!
	 * mustache.js - Logic-less {{mustache}} templates with JavaScript
	 * http://github.com/janl/mustache.js
	 */

	var objectToString = Object.prototype.toString;
	var isArray =
		Array.isArray ||
		function isArrayPolyfill(object) {
			return objectToString.call(object) === "[object Array]";
		};

	function isFunction(object) {
		return typeof object === "function";
	}

	/**
	 * More correct typeof string handling array
	 * which normally returns typeof 'object'
	 */
	function typeStr(obj) {
		return isArray(obj) ? "array" : typeof obj;
	}

	function escapeRegExp(string) {
		return string.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&");
	}

	/**
	 * Null safe way of checking whether or not an object,
	 * including its prototype, has a given property
	 */
	function hasProperty(obj, propName) {
		return obj != null && typeof obj === "object" && propName in obj;
	}

	/**
	 * Safe way of detecting whether or not the given thing is a primitive and
	 * whether it has the given property
	 */
	function primitiveHasOwnProperty(primitive, propName) {
		return primitive != null && typeof primitive !== "object" && primitive.hasOwnProperty && primitive.hasOwnProperty(propName);
	}

	// Workaround for https://issues.apache.org/jira/browse/COUCHDB-577
	// See https://github.com/janl/mustache.js/issues/189
	var regExpTest = RegExp.prototype.test;
	function testRegExp(re, string) {
		return regExpTest.call(re, string);
	}

	var nonSpaceRe = /\S/;
	function isWhitespace(string) {
		return !testRegExp(nonSpaceRe, string);
	}

	var entityMap = {
		"&": "&amp;",
		"<": "&lt;",
		">": "&gt;",
		'"': "&quot;",
		"'": "&#39;",
		"/": "&#x2F;",
		"`": "&#x60;",
		"=": "&#x3D;",
	};

	function escapeHtml(string) {
		return String(string).replace(/[&<>"'`=\/]/g, function fromEntityMap(s) {
			return entityMap[s];
		});
	}

	var whiteRe = /\s*/;
	var spaceRe = /\s+/;
	var equalsRe = /\s*=/;
	var curlyRe = /\s*\}/;
	var tagRe = /#|\^|\/|>|\{|&|=|!/;

	/**
	 * Breaks up the given `template` string into a tree of tokens. If the `tags`
	 * argument is given here it must be an array with two string values: the
	 * opening and closing tags used in the template (e.g. [ "<%", "%>" ]). Of
	 * course, the default is to use mustaches (i.e. mustache.tags).
	 *
	 * A token is an array with at least 4 elements. The first element is the
	 * mustache symbol that was used inside the tag, e.g. "#" or "&". If the tag
	 * did not contain a symbol (i.e. {{myValue}}) this element is "name". For
	 * all text that appears outside a symbol this element is "text".
	 *
	 * The second element of a token is its "value". For mustache tags this is
	 * whatever else was inside the tag besides the opening symbol. For text tokens
	 * this is the text itself.
	 *
	 * The third and fourth elements of the token are the start and end indices,
	 * respectively, of the token in the original template.
	 *
	 * Tokens that are the root node of a subtree contain two more elements: 1) an
	 * array of tokens in the subtree and 2) the index in the original template at
	 * which the closing tag for that section begins.
	 *
	 * Tokens for partials also contain two more elements: 1) a string value of
	 * indendation prior to that tag and 2) the index of that tag on that line -
	 * eg a value of 2 indicates the partial is the third tag on this line.
	 */
	function parseTemplate(template, tags) {
		if (!template) return [];
		var lineHasNonSpace = false;
		var sections = []; // Stack to hold section tokens
		var tokens = []; // Buffer to hold the tokens
		var spaces = []; // Indices of whitespace tokens on the current line
		var hasTag = false; // Is there a {{tag}} on the current line?
		var nonSpace = false; // Is there a non-space char on the current line?
		var indentation = ""; // Tracks indentation for tags that use it
		var tagIndex = 0; // Stores a count of number of tags encountered on a line

		// Strips all whitespace tokens array for the current line
		// if there was a {{#tag}} on it and otherwise only space.
		function stripSpace() {
			if (hasTag && !nonSpace) {
				while (spaces.length) delete tokens[spaces.pop()];
			} else {
				spaces = [];
			}

			hasTag = false;
			nonSpace = false;
		}

		var openingTagRe, closingTagRe, closingCurlyRe;
		function compileTags(tagsToCompile) {
			if (typeof tagsToCompile === "string") tagsToCompile = tagsToCompile.split(spaceRe, 2);

			if (!isArray(tagsToCompile) || tagsToCompile.length !== 2) throw new Error("Invalid tags: " + tagsToCompile);

			openingTagRe = new RegExp(escapeRegExp(tagsToCompile[0]) + "\\s*");
			closingTagRe = new RegExp("\\s*" + escapeRegExp(tagsToCompile[1]));
			closingCurlyRe = new RegExp("\\s*" + escapeRegExp("}" + tagsToCompile[1]));
		}

		compileTags(tags || mustache.tags);

		var scanner = new Scanner(template);

		var start, type, value, chr, token, openSection;
		while (!scanner.eos()) {
			start = scanner.pos;

			// Match any text between tags.
			value = scanner.scanUntil(openingTagRe);

			if (value) {
				for (var i = 0, valueLength = value.length; i < valueLength; ++i) {
					chr = value.charAt(i);

					if (isWhitespace(chr)) {
						spaces.push(tokens.length);
						indentation += chr;
					} else {
						nonSpace = true;
						lineHasNonSpace = true;
						indentation += " ";
					}

					tokens.push(["text", chr, start, start + 1]);
					start += 1;

					// Check for whitespace on the current line.
					if (chr === "\n") {
						stripSpace();
						indentation = "";
						tagIndex = 0;
						lineHasNonSpace = false;
					}
				}
			}

			// Match the opening tag.
			if (!scanner.scan(openingTagRe)) break;

			hasTag = true;

			// Get the tag type.
			type = scanner.scan(tagRe) || "name";
			scanner.scan(whiteRe);

			// Get the tag value.
			if (type === "=") {
				value = scanner.scanUntil(equalsRe);
				scanner.scan(equalsRe);
				scanner.scanUntil(closingTagRe);
			} else if (type === "{") {
				value = scanner.scanUntil(closingCurlyRe);
				scanner.scan(curlyRe);
				scanner.scanUntil(closingTagRe);
				type = "&";
			} else {
				value = scanner.scanUntil(closingTagRe);
			}

			// Match the closing tag.
			if (!scanner.scan(closingTagRe)) throw new Error("Unclosed tag at " + scanner.pos);

			if (type == ">") {
				token = [type, value, start, scanner.pos, indentation, tagIndex, lineHasNonSpace];
			} else {
				token = [type, value, start, scanner.pos];
			}
			tagIndex++;
			tokens.push(token);

			if (type === "#" || type === "^") {
				sections.push(token);
			} else if (type === "/") {
				// Check section nesting.
				openSection = sections.pop();

				if (!openSection) throw new Error('Unopened section "' + value + '" at ' + start);

				if (openSection[1] !== value) throw new Error('Unclosed section "' + openSection[1] + '" at ' + start);
			} else if (type === "name" || type === "{" || type === "&") {
				nonSpace = true;
			} else if (type === "=") {
				// Set the tags for the next time around.
				compileTags(value);
			}
		}

		stripSpace();

		// Make sure there are no open sections when we're done.
		openSection = sections.pop();

		if (openSection) throw new Error('Unclosed section "' + openSection[1] + '" at ' + scanner.pos);

		return nestTokens(squashTokens(tokens));
	}

	/**
	 * Combines the values of consecutive text tokens in the given `tokens` array
	 * to a single token.
	 */
	function squashTokens(tokens) {
		var squashedTokens = [];

		var token, lastToken;
		for (var i = 0, numTokens = tokens.length; i < numTokens; ++i) {
			token = tokens[i];

			if (token) {
				if (token[0] === "text" && lastToken && lastToken[0] === "text") {
					lastToken[1] += token[1];
					lastToken[3] = token[3];
				} else {
					squashedTokens.push(token);
					lastToken = token;
				}
			}
		}

		return squashedTokens;
	}

	/**
	 * Forms the given array of `tokens` into a nested tree structure where
	 * tokens that represent a section have two additional items: 1) an array of
	 * all tokens that appear in that section and 2) the index in the original
	 * template that represents the end of that section.
	 */
	function nestTokens(tokens) {
		var nestedTokens = [];
		var collector = nestedTokens;
		var sections = [];

		var token, section;
		for (var i = 0, numTokens = tokens.length; i < numTokens; ++i) {
			token = tokens[i];

			switch (token[0]) {
				case "#":
				case "^":
					collector.push(token);
					sections.push(token);
					collector = token[4] = [];
					break;
				case "/":
					section = sections.pop();
					section[5] = token[2];
					collector = sections.length > 0 ? sections[sections.length - 1][4] : nestedTokens;
					break;
				default:
					collector.push(token);
			}
		}

		return nestedTokens;
	}

	/**
	 * A simple string scanner that is used by the template parser to find
	 * tokens in template strings.
	 */
	function Scanner(string) {
		this.string = string;
		this.tail = string;
		this.pos = 0;
	}

	/**
	 * Returns `true` if the tail is empty (end of string).
	 */
	Scanner.prototype.eos = function eos() {
		return this.tail === "";
	};

	/**
	 * Tries to match the given regular expression at the current position.
	 * Returns the matched text if it can match, the empty string otherwise.
	 */
	Scanner.prototype.scan = function scan(re) {
		var match = this.tail.match(re);

		if (!match || match.index !== 0) return "";

		var string = match[0];

		this.tail = this.tail.substring(string.length);
		this.pos += string.length;

		return string;
	};

	/**
	 * Skips all text until the given regular expression can be matched. Returns
	 * the skipped string, which is the entire tail if no match can be made.
	 */
	Scanner.prototype.scanUntil = function scanUntil(re) {
		var index = this.tail.search(re),
			match;

		switch (index) {
			case -1:
				match = this.tail;
				this.tail = "";
				break;
			case 0:
				match = "";
				break;
			default:
				match = this.tail.substring(0, index);
				this.tail = this.tail.substring(index);
		}

		this.pos += match.length;

		return match;
	};

	/**
	 * Represents a rendering context by wrapping a view object and
	 * maintaining a reference to the parent context.
	 */
	function Context(view, parentContext) {
		this.view = view;
		this.cache = { ".": this.view };
		this.parent = parentContext;
	}

	/**
	 * Creates a new context using the given view with this context
	 * as the parent.
	 */
	Context.prototype.push = function push(view) {
		return new Context(view, this);
	};

	/**
	 * Returns the value of the given name in this context, traversing
	 * up the context hierarchy if the value is absent in this context's view.
	 */
	Context.prototype.lookup = function lookup(name) {
		var cache = this.cache;

		var value;
		if (cache.hasOwnProperty(name)) {
			value = cache[name];
		} else {
			var context = this,
				intermediateValue,
				names,
				index,
				lookupHit = false;

			while (context) {
				if (name.indexOf(".") > 0) {
					intermediateValue = context.view;
					names = name.split(".");
					index = 0;

					/**
					 * Using the dot notion path in `name`, we descend through the
					 * nested objects.
					 *
					 * To be certain that the lookup has been successful, we have to
					 * check if the last object in the path actually has the property
					 * we are looking for. We store the result in `lookupHit`.
					 *
					 * This is specially necessary for when the value has been set to
					 * `undefined` and we want to avoid looking up parent contexts.
					 *
					 * In the case where dot notation is used, we consider the lookup
					 * to be successful even if the last "object" in the path is
					 * not actually an object but a primitive (e.g., a string, or an
					 * integer), because it is sometimes useful to access a property
					 * of an autoboxed primitive, such as the length of a string.
					 **/
					while (intermediateValue != null && index < names.length) {
						if (index === names.length - 1) lookupHit = hasProperty(intermediateValue, names[index]) || primitiveHasOwnProperty(intermediateValue, names[index]);

						intermediateValue = intermediateValue[names[index++]];
					}
				} else {
					intermediateValue = context.view[name];

					/**
					 * Only checking against `hasProperty`, which always returns `false` if
					 * `context.view` is not an object. Deliberately omitting the check
					 * against `primitiveHasOwnProperty` if dot notation is not used.
					 *
					 * Consider this example:
					 * ```
					 * Mustache.render("The length of a football field is {{#length}}{{length}}{{/length}}.", {length: "100 yards"})
					 * ```
					 *
					 * If we were to check also against `primitiveHasOwnProperty`, as we do
					 * in the dot notation case, then render call would return:
					 *
					 * "The length of a football field is 9."
					 *
					 * rather than the expected:
					 *
					 * "The length of a football field is 100 yards."
					 **/
					lookupHit = hasProperty(context.view, name);
				}

				if (lookupHit) {
					value = intermediateValue;
					break;
				}

				context = context.parent;
			}

			cache[name] = value;
		}

		if (isFunction(value)) value = value.call(this.view);

		return value;
	};

	/**
	 * A Writer knows how to take a stream of tokens and render them to a
	 * string, given a context. It also maintains a cache of templates to
	 * avoid the need to parse the same template twice.
	 */
	function Writer() {
		this.templateCache = {
			_cache: {},
			set: function set(key, value) {
				this._cache[key] = value;
			},
			get: function get(key) {
				return this._cache[key];
			},
			clear: function clear() {
				this._cache = {};
			},
		};
	}

	/**
	 * Clears all cached templates in this writer.
	 */
	Writer.prototype.clearCache = function clearCache() {
		if (typeof this.templateCache !== "undefined") {
			this.templateCache.clear();
		}
	};

	/**
	 * Parses and caches the given `template` according to the given `tags` or
	 * `mustache.tags` if `tags` is omitted,  and returns the array of tokens
	 * that is generated from the parse.
	 */
	Writer.prototype.parse = function parse(template, tags) {
		var cache = this.templateCache;
		var cacheKey = template + ":" + (tags || mustache.tags).join(":");
		var isCacheEnabled = typeof cache !== "undefined";
		var tokens = isCacheEnabled ? cache.get(cacheKey) : undefined;

		if (tokens == undefined) {
			tokens = parseTemplate(template, tags);
			isCacheEnabled && cache.set(cacheKey, tokens);
		}
		return tokens;
	};

	/**
	 * High-level method that is used to render the given `template` with
	 * the given `view`.
	 *
	 * The optional `partials` argument may be an object that contains the
	 * names and templates of partials that are used in the template. It may
	 * also be a function that is used to load partial templates on the fly
	 * that takes a single argument: the name of the partial.
	 *
	 * If the optional `tags` argument is given here it must be an array with two
	 * string values: the opening and closing tags used in the template (e.g.
	 * [ "<%", "%>" ]). The default is to mustache.tags.
	 */
	Writer.prototype.render = function render(template, view, partials, tags) {
		var tokens = this.parse(template, tags);
		var context = view instanceof Context ? view : new Context(view, undefined);
		return this.renderTokens(tokens, context, partials, template, tags);
	};

	/**
	 * Low-level method that renders the given array of `tokens` using
	 * the given `context` and `partials`.
	 *
	 * Note: The `originalTemplate` is only ever used to extract the portion
	 * of the original template that was contained in a higher-order section.
	 * If the template doesn't use higher-order sections, this argument may
	 * be omitted.
	 */
	Writer.prototype.renderTokens = function renderTokens(tokens, context, partials, originalTemplate, tags) {
		var buffer = "";

		var token, symbol, value;
		for (var i = 0, numTokens = tokens.length; i < numTokens; ++i) {
			value = undefined;
			token = tokens[i];
			symbol = token[0];

			if (symbol === "#") value = this.renderSection(token, context, partials, originalTemplate);
			else if (symbol === "^") value = this.renderInverted(token, context, partials, originalTemplate);
			else if (symbol === ">") value = this.renderPartial(token, context, partials, tags);
			else if (symbol === "&") value = this.unescapedValue(token, context);
			else if (symbol === "name") value = this.escapedValue(token, context);
			else if (symbol === "text") value = this.rawValue(token);

			if (value !== undefined) buffer += value;
		}

		return buffer;
	};

	Writer.prototype.renderSection = function renderSection(token, context, partials, originalTemplate) {
		var self = this;
		var buffer = "";
		var value = context.lookup(token[1]);

		// This function is used to render an arbitrary template
		// in the current context by higher-order sections.
		function subRender(template) {
			return self.render(template, context, partials);
		}

		if (!value) return;

		if (isArray(value)) {
			for (var j = 0, valueLength = value.length; j < valueLength; ++j) {
				buffer += this.renderTokens(token[4], context.push(value[j]), partials, originalTemplate);
			}
		} else if (typeof value === "object" || typeof value === "string" || typeof value === "number") {
			buffer += this.renderTokens(token[4], context.push(value), partials, originalTemplate);
		} else if (isFunction(value)) {
			if (typeof originalTemplate !== "string") throw new Error("Cannot use higher-order sections without the original template");

			// Extract the portion of the original template that the section contains.
			value = value.call(context.view, originalTemplate.slice(token[3], token[5]), subRender);

			if (value != null) buffer += value;
		} else {
			buffer += this.renderTokens(token[4], context, partials, originalTemplate);
		}
		return buffer;
	};

	Writer.prototype.renderInverted = function renderInverted(token, context, partials, originalTemplate) {
		var value = context.lookup(token[1]);

		// Use JavaScript's definition of falsy. Include empty arrays.
		// See https://github.com/janl/mustache.js/issues/186
		if (!value || (isArray(value) && value.length === 0)) return this.renderTokens(token[4], context, partials, originalTemplate);
	};

	Writer.prototype.indentPartial = function indentPartial(partial, indentation, lineHasNonSpace) {
		var filteredIndentation = indentation.replace(/[^ \t]/g, "");
		var partialByNl = partial.split("\n");
		for (var i = 0; i < partialByNl.length; i++) {
			if (partialByNl[i].length && (i > 0 || !lineHasNonSpace)) {
				partialByNl[i] = filteredIndentation + partialByNl[i];
			}
		}
		return partialByNl.join("\n");
	};

	Writer.prototype.renderPartial = function renderPartial(token, context, partials, tags) {
		if (!partials) return;

		var value = isFunction(partials) ? partials(token[1]) : partials[token[1]];
		if (value != null) {
			var lineHasNonSpace = token[6];
			var tagIndex = token[5];
			var indentation = token[4];
			var indentedValue = value;
			if (tagIndex == 0 && indentation) {
				indentedValue = this.indentPartial(value, indentation, lineHasNonSpace);
			}
			return this.renderTokens(this.parse(indentedValue, tags), context, partials, indentedValue, tags);
		}
	};

	Writer.prototype.unescapedValue = function unescapedValue(token, context) {
		var value = context.lookup(token[1]);
		if (value != null) return value;
	};

	Writer.prototype.escapedValue = function escapedValue(token, context) {
		var value = context.lookup(token[1]);
		if (value != null) return mustache.escape(value);
	};

	Writer.prototype.rawValue = function rawValue(token) {
		return token[1];
	};

	var mustache = {
		name: "mustache.js",
		version: "4.0.1",
		tags: ["{{", "}}"],
		clearCache: undefined,
		escape: undefined,
		parse: undefined,
		render: undefined,
		Scanner: undefined,
		Context: undefined,
		Writer: undefined,
		/**
		 * Allows a user to override the default caching strategy, by providing an
		 * object with set, get and clear methods. This can also be used to disable
		 * the cache by setting it to the literal `undefined`.
		 */
		set templateCache(cache) {
			defaultWriter.templateCache = cache;
		},
		/**
		 * Gets the default or overridden caching object from the default writer.
		 */
		get templateCache() {
			return defaultWriter.templateCache;
		},
	};

	// All high-level mustache.* functions use this writer.
	var defaultWriter = new Writer();

	/**
	 * Clears all cached templates in the default writer.
	 */
	mustache.clearCache = function clearCache() {
		return defaultWriter.clearCache();
	};

	/**
	 * Parses and caches the given template in the default writer and returns the
	 * array of tokens it contains. Doing this ahead of time avoids the need to
	 * parse templates on the fly as they are rendered.
	 */
	mustache.parse = function parse(template, tags) {
		return defaultWriter.parse(template, tags);
	};

	/**
	 * Renders the `template` with the given `view` and `partials` using the
	 * default writer. If the optional `tags` argument is given here it must be an
	 * array with two string values: the opening and closing tags used in the
	 * template (e.g. [ "<%", "%>" ]). The default is to mustache.tags.
	 */
	mustache.render = function render(template, view, partials, tags) {
		if (typeof template !== "string") {
			throw new TypeError('Invalid template! Template should be a "string" ' + 'but "' + typeStr(template) + '" was given as the first ' + "argument for mustache#render(template, view, partials)");
		}

		return defaultWriter.render(template, view, partials, tags);
	};

	// Export the escaping function so that the user may override it.
	// See https://github.com/janl/mustache.js/issues/244
	mustache.escape = escapeHtml;

	// Export these mainly for testing, but also for advanced usage.
	mustache.Scanner = Scanner;
	mustache.Context = Context;
	mustache.Writer = Writer;

	return mustache;
});

// mustache renderer
function mustRender(templateId, contentObject, target) {
	var template = $(templateId).html();
	var content = Mustache.render(template, contentObject);
	$(target).html(content);
}
